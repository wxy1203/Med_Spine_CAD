
#ifndef __include__Include__SPN_Cmn_Math__h__
#define __include__Include__SPN_Cmn_Math__h__

#pragma once

#ifdef SPN_Cmn_Math__USE_STC_LIB
#define SPN_Cmn_Math__MAKE_STC_LIB
#endif // 

#include "_SPN_Cmn_Math__AllExport.h"

#endif //  //__include__Include__SPN_Cmn_Math__h__

