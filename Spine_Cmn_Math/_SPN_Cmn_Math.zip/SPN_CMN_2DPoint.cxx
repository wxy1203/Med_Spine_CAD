// SPN_Cmn_DPoint.cpp: implementation of the CSPN_Cmn_2DPoint class.
//
//////////////////////////////////////////////////////////////////////

//{{pch========================================================================
#include "pch.h"
#include "_SPN_Cmn_Math__inLib.h"
#include "SPN_Cmn_3DMtx.h"
//}}pch========================================================================

#include "_SPN_Cmn_Math__inLib.h"
//#include "_SPN_Cmn_Math__inLib.h"

//
#ifdef _DEBUG
#	ifdef _USE_VC_DBG_NEW
#		define new DEBUG_NEW
#	else
#		ifdef _USE_SPN_DBG_NEW
#			define new _DEBUG_NEW
//#			define delete _DEBUG_DEL
#		endif
#	endif
#endif // 
//

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#ifdef _DEBUG
void TestCompile_CSPN_Cmn_2DPoint()
{
	//float f1 = 1;
	//float f2 = 2;
	//CPointInt P(0,0 );

	//CSPN_Cmn_2DPoint<float> P1(f1, f2);
	//CSPN_Cmn_2DPoint<float> P2(P);
	//CSPN_Cmn_2DPoint<float> P3(P);
	//SSPN_Cmn_2DPoint<float> P4 = P3;

	//P = QPointF(0,0 );
	//P4 = QPointF(0,0 );

	//P = QPoint(0,0 );
	//P4 = QPoint(0,0 );

	//P3 = P = P;

	//P3 = P - P;
	//P3 = P + P;

	//P4 = .0;
	//P3 = .0;

	//P3 += 0;
	//P3 -= 0;

	//P[0] = P.x();
	//P[1] = P.y();

	//P.x(f);
	//P.y(f);

	//P.GetVectLength();
	//P.GetVectLengthSq();

	//P.GetDistTo	( P	);
	//P.GetDistTo	( P );

	//CSPN_Cmn_2DSize<float> SzD;
	//P.GetDistTo(P, &SzD);

	//P.IsPointNearPoint(P, f);
	//P.IsPointNearLine (P, P, f);

	////P = P.Get_CPoint();

	//P.Construct(P);
	//P = P;
	//P += P;
	//P -= P;

	//P = 1f;
	//P /= 1f;
	//
	//P = P.NegPoint(P);

	//P > P;
	//P < P;
	//P == P;
	//P != P;
	//P >= P;
	//P <= P;

	//P.Compare(P);

	//CSPN_Cmn_2DPoint<float>::SetSortKey();
	//CSPN_Cmn_2DPoint<float>::IsSortKey	();
	//CSPN_Cmn_2DPoint<float>::GetSortKey();

	//CSPN_Cmn_CArray<SPntD_Flt, SPntD_Flt&> ArrPoint;

	//CSPN_Cmn_2DPoint<float>::InsertPoint(P, P, ArrPoint, 1, 1, 1);

}

#endif // 
