#pragma once

class SPN_CMN_MATH_EXPORT SPN_Cmn_MATH
{
public:
	SPN_Cmn_MATH();
};
