#pragma once

inline void f()
{
	;
}