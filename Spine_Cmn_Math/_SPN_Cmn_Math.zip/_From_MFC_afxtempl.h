
#ifndef __include__From_MFC_afxTempl__H__
#define __include__From_MFC_afxTempl__H__

#include "_From_MFC_minWinDef.h"
#include "_From_MFC_windef.h"

// This is a part of the Microsoft Foundation Classes C++ library.
// Copyright (C) Microsoft Corporation
// All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Foundation Classes Reference and related
// electronic documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft Foundation Classes product.
//
//#ifndef __AFXTEMPL_H__
//#define __AFXTEMPL_H__
//
//#ifndef __AFXPLEX_H__
//	#include <afxplex_.h>
//#endif // 
//
//#ifdef _AFX_MINREBUILD
//#	pragma component(minrebuild, off)
//#endif //  
//
//#ifdef _AFX_PACKING
//#	pragma pack(push, _AFX_PACKING)
//#endif // 
//
//#ifdef _DEBUG
//#endif // 
//
//#	pragma warning( push )
//#	pragma warning( disable: 4505 4127 )
//
///////////////////////////////////////////////////////////////////////////////
//// global helpers (can be overridden)
//
//#	pragma push_macro("new")
//
//#ifndef _INC_NEW
//	#include <new.h>
//#endif // 
//
//namespace ATL
//{
//	class CComBSTR;
//}
//using ATL::CComBSTR;
//




//#define int/*INT_PTR*/ size_t
//#define UINT unsigned int
//#define BOOL bool
//#define DWORD double WORD 

//#define ASSERT Q_ASSERT
//#define SPN_ASSERT Q_ASSERT
#include "_SPN_Cmn_Math__Global.h"

// the two functions below are deprecated.  Use a constructor/destructor instead.
#	pragma deprecated( DestructElements )
#	pragma deprecated( ConstructElements )

template<class TYPE>
inline void /*AFXAPI*/ CopyElements_(TYPE* pDest, const TYPE* pSrc, int/*INT_PTR*/ nCount)
{
	SPN_ASSERT(nCount == 0 || pDest != 0 && pSrc != 0);
	//SPN_ASSERT(nCount == 0 ||
	//	AfxIsValidAddress(pDest, (size_t)nCount * sizeof(TYPE)));
	//SPN_ASSERT(nCount == 0 ||
	//	AfxIsValidAddress(pSrc, (size_t)nCount * sizeof(TYPE)));

	// default is element-copy using assignment
	while (nCount--)
		*pDest++ = *pSrc++;
};

//template<class TYPE>
//void /*AFXAPI*/ SerializeElements(CArchive& ar, TYPE* pElements, int/*INT_PTR*/ nCount)
//{
//	SPN_ASSERT(nCount == 0 || pElements != NULL);
//	SPN_ASSERT(nCount == 0 ||
//		AfxIsValidAddress(pElements, (size_t)nCount * sizeof(TYPE)));
//
//	// default is bit-wise read/write
//	if (ar.IsStoring())
//	{
//		TYPE* pData;
//		UINT_PTR nElementsLeft;
//
//		nElementsLeft = nCount;
//		pData = pElements;
//		while( nElementsLeft > 0 )
//		{
//			UINT nElementsToWrite;
//
//			nElementsToWrite = UINT(__min(nElementsLeft, INT_MAX/sizeof(TYPE)));
//			ar.Write(pData, nElementsToWrite*sizeof(TYPE));
//			nElementsLeft -= nElementsToWrite;
//			pData += nElementsToWrite;
//		}
//	}
//	else
//	{
//		TYPE* pData;
//		UINT_PTR nElementsLeft;
//
//		nElementsLeft = nCount;
//		pData = pElements;
//		while( nElementsLeft > 0 )
//		{
//			UINT nElementsToRead;
//
//			nElementsToRead = UINT(__min(nElementsLeft, INT_MAX/sizeof(TYPE)));
//			ar.EnsureRead(pData, nElementsToRead*sizeof(TYPE));
//			nElementsLeft -= nElementsToRead;
//			pData += nElementsToRead;
//		}
//	}
//}
//
//template<class TYPE>
//void /*AFXAPI*/ SerializeElementsInsertExtract(CArchive& ar, TYPE* pElements, 
//	int/*INT_PTR*/ nCount)
//{
//	SPN_ASSERT(nCount == 0 || pElements != NULL);
//	SPN_ASSERT((nCount == 0) || 
//		(AfxIsValidAddress(pElements, nCount*sizeof(TYPE))));
//
//	if (nCount == 0 || pElements == NULL)
//	{
//		return;
//	}
//
//	if (ar.IsStoring())
//	{
//		for (; nCount--; ++pElements)
//			ar << *pElements;
//	}
//	else
//	{
//		for (; nCount--; ++pElements)
//			ar >> *pElements;
//	}
//}

//#ifdef _DEBUG
//template<class TYPE>
//void /*AFXAPI*/ DumpElements(CDumpContext& dc, const TYPE* pElements, int/*INT_PTR*/ nCount)
//{
//	SPN_ASSERT(nCount == 0 || pElements != NULL);
//	SPN_ASSERT(nCount == 0 ||
//		AfxIsValidAddress(pElements, (size_t)nCount * sizeof(TYPE), FALSE));
//	(dc); // not used
//	(pElements);  // not used
//	(nCount); // not used
//
//	// default does nothing
//}
//#endif // 

template<class TYPE, class ARG_TYPE>
BOOL /*AFXAPI*/ CompareElements_(const TYPE* pElement1, const ARG_TYPE* pElement2)
{
	SPN_ASSERT(pElement1 != NULL && pElement2 != NULL);
	SPN_ASSERT(AfxIsValidAddress(pElement1, sizeof(TYPE), FALSE));
	SPN_ASSERT(AfxIsValidAddress(pElement2, sizeof(ARG_TYPE), FALSE));

	return *pElement1 == *pElement2;
}

template<class ARG_KEY>
inline UINT /*AFXAPI*/ HashKey_(ARG_KEY key)
{
	// (algorithm copied from STL hash in xfunctional)
#	pragma warning(suppress: 4302) // 'type cast' : truncation
	ldiv_t HashVal = ldiv((long)(ARG_KEY)key, 127773);
	HashVal.rem = 16807 * HashVal.rem - 2836 * HashVal.quot;
	if (HashVal.rem < 0)
		HashVal.rem += 2147483647;
	return ((UINT)HashVal.rem);
}

template<> inline UINT /*AFXAPI*/ HashKey_<__int64>(__int64 key)
{
	// (algorithm copied from STL hash in xfunctional)
	return (HashKey_<DWORD>((DWORD)(key & 0xffffffffUL)) ^ HashKey_<DWORD>((DWORD)(key >> 32)));
}

// special versions for std::string
//template<> void /*AFXAPI*/ SerializeElements<std::stringA> (CArchive& ar, std::stringA* pElements, int/*INT_PTR*/ nCount);
//template<> void /*AFXAPI*/ SerializeElements<std::stringW> (CArchive& ar, std::stringW* pElements, int/*INT_PTR*/ nCount);
//template<> UINT /*AFXAPI*/ HashKey_<LPCWSTR> (LPCWSTR key);
//template<> UINT /*AFXAPI*/ HashKey_<LPCSTR> (LPCSTR key);

// special versions for CComBSTR
// template<> void /*AFXAPI*/ SerializeElements<CComBSTR> (CArchive& ar, CComBSTR* pElements, int/*INT_PTR*/ nCount);
// template<> UINT /*AFXAPI*/ HashKey_<CComBSTR> (CComBSTR key);

// forward declarations
class COleVariant;
struct tagVARIANT;

// special versions for COleVariant

//
//template<> void /*AFXAPI*/ CopyElements_<COleVariant> (COleVariant* pDest, const COleVariant* pSrc, int/*INT_PTR*/ nCount);
//template<> void /*AFXAPI*/ SerializeElements<COleVariant> (CArchive& ar, COleVariant* pElements, int/*INT_PTR*/ nCount);
//#ifdef _DEBUG
//template<> void /*AFXAPI*/ DumpElements<COleVariant> (CDumpContext& dc, const COleVariant* pElements, int/*INT_PTR*/ nCount);
//#endif // 
//template<> UINT /*AFXAPI*/ HashKey_<const struct tagVARIANT&> (const struct tagVARIANT& var);

/*============================================================================*/
// CArrayT<TYPE, ARG_TYPE>

template<class TYPE, class ARG_TYPE = const TYPE&>
class CArrayT/* : public CObject*/
{
public:
// Construction
	CArrayT();

// Attributes
	int/*INT_PTR*/ GetSize() const;
	int/*INT_PTR*/ GetCount() const;
	BOOL IsEmpty() const;
	int/*INT_PTR*/ GetUpperBound() const;
	void SetSize(int/*INT_PTR*/ nNewSize, int/*INT_PTR*/ nGrowBy = -1);

// Operations
	// Clean up
	void FreeExtra();
	void RemoveAll();

	// Accessing elements
	const TYPE& GetAt(int/*INT_PTR*/ nIndex) const;
	TYPE& GetAt(int/*INT_PTR*/ nIndex);
	void SetAt(int/*INT_PTR*/ nIndex, ARG_TYPE newElement);
	const TYPE& ElementAt(int/*INT_PTR*/ nIndex) const;
	TYPE& ElementAt(int/*INT_PTR*/ nIndex);

	// Direct Access to the element data (may return NULL)
	const TYPE* GetData() const;
	TYPE* GetData();

	// Potentially growing the array
	void SetAtGrow(int/*INT_PTR*/ nIndex, const ARG_TYPE newElement);

	//[11_9 17:27:49 ]:int/*INT_PTR*/ Add(ARG_TYPE newElement);
	int/*INT_PTR*/ Add(const ARG_TYPE newElement);

	int/*INT_PTR*/ Append(const CArrayT& src);
	void Copy(const CArrayT& src);

	// overloaded operator helpers
	const TYPE& operator[](int/*INT_PTR*/ nIndex) const;
	TYPE& operator[](int/*INT_PTR*/ nIndex);

	// Operations that move elements around
	void InsertAt(int/*INT_PTR*/ nIndex, ARG_TYPE newElement, int/*INT_PTR*/ nCount = 1);
	void RemoveAt(int/*INT_PTR*/ nIndex, int/*INT_PTR*/ nCount = 1);
	void InsertAt(int/*INT_PTR*/ nStartIndex, CArrayT* pNewArray);

// Implementation
protected:
	TYPE* m_pData;   // the actual array of data
	int/*INT_PTR*/ m_nSize;     // # of elements (upperBound - 1)
	int/*INT_PTR*/ m_nMaxSize;  // max allocated
	int/*INT_PTR*/ m_nGrowBy;   // grow amount

public:
	virtual ~CArrayT();
	//void Serialize(CArchive&);
#ifdef _DEBUG
	//	void Dump(CDumpContext&) const;
	void AssertValid() const;
#endif // 
};

/*============================================================================*/
// CArrayT<TYPE, ARG_TYPE> inline functions

template<class TYPE, class ARG_TYPE>
inline int/*INT_PTR*/ CArrayT<TYPE, ARG_TYPE>::GetSize() const
	{ return m_nSize; }
template<class TYPE, class ARG_TYPE>
inline int/*INT_PTR*/ CArrayT<TYPE, ARG_TYPE>::GetCount() const
	{ return m_nSize; }
template<class TYPE, class ARG_TYPE>
inline BOOL CArrayT<TYPE, ARG_TYPE>::IsEmpty() const
	{ return m_nSize == 0; }
template<class TYPE, class ARG_TYPE>
inline int/*INT_PTR*/ CArrayT<TYPE, ARG_TYPE>::GetUpperBound() const
	{ return m_nSize-1; }
template<class TYPE, class ARG_TYPE>
inline void CArrayT<TYPE, ARG_TYPE>::RemoveAll()
	{ SetSize(0, -1); }
template<class TYPE, class ARG_TYPE>
inline TYPE& CArrayT<TYPE, ARG_TYPE>::GetAt(int/*INT_PTR*/ nIndex)
{ 
	SPN_ASSERT(nIndex >= 0 && nIndex < m_nSize);
	//[3_7 21:05:07 ]:if(nIndex >= 0 && nIndex < m_nSize)
		return m_pData[nIndex]; 
	//[3_7 21:05:12 ]:return;// AfxThrowInvalidArgException();
}
template<class TYPE, class ARG_TYPE>
inline const TYPE& CArrayT<TYPE, ARG_TYPE>::GetAt(int/*INT_PTR*/ nIndex) const
{
	SPN_ASSERT(nIndex >= 0 && nIndex < m_nSize);
	//[3_7 21:05:24 ]:if(nIndex >= 0 && nIndex < m_nSize)
		return m_pData[nIndex]; 
	//[3_7 21:05:28 ]:return;// AfxThrowInvalidArgException();
}
template<class TYPE, class ARG_TYPE>
inline void CArrayT<TYPE, ARG_TYPE>::SetAt(int/*INT_PTR*/ nIndex, ARG_TYPE newElement)
{ 
	SPN_ASSERT(nIndex >= 0 && nIndex < m_nSize);
	if(nIndex >= 0 && nIndex < m_nSize)
		m_pData[nIndex] = newElement; 
	else
		return;// AfxThrowInvalidArgException();
}
template<class TYPE, class ARG_TYPE>
inline const TYPE& CArrayT<TYPE, ARG_TYPE>::ElementAt(int/*INT_PTR*/ nIndex) const
{ 
	SPN_ASSERT(nIndex >= 0 && nIndex < m_nSize);
	//if(nIndex >= 0 && nIndex < m_nSize)
		return m_pData[nIndex]; 
	//return;// AfxThrowInvalidArgException();
}
template<class TYPE, class ARG_TYPE>
inline TYPE& CArrayT<TYPE, ARG_TYPE>::ElementAt(int/*INT_PTR*/ nIndex)
{ 
	SPN_ASSERT(nIndex >= 0 && nIndex < m_nSize);
	//if(nIndex >= 0 && nIndex < m_nSize)
		return m_pData[nIndex]; 
	//return;// AfxThrowInvalidArgException();
}
template<class TYPE, class ARG_TYPE>
inline const TYPE* CArrayT<TYPE, ARG_TYPE>::GetData() const
	{ return (const TYPE*)m_pData; }
template<class TYPE, class ARG_TYPE>
inline TYPE* CArrayT<TYPE, ARG_TYPE>::GetData()
	{ return (TYPE*)m_pData; }
template<class TYPE, class ARG_TYPE>
//[11_9 17:28:37 ]:inline int/*INT_PTR*/ CArrayT<TYPE, ARG_TYPE>::Add(ARG_TYPE newElement)
inline int/*INT_PTR*/ CArrayT<TYPE, ARG_TYPE>::Add(const ARG_TYPE newElement)
	{ int/*INT_PTR*/ nIndex = m_nSize;
		SetAtGrow(nIndex, newElement);
		return nIndex; }
template<class TYPE, class ARG_TYPE>
inline const TYPE& CArrayT<TYPE, ARG_TYPE>::operator[](int/*INT_PTR*/ nIndex) const
	{ return GetAt(nIndex); }
template<class TYPE, class ARG_TYPE>
inline TYPE& CArrayT<TYPE, ARG_TYPE>::operator[](int/*INT_PTR*/ nIndex)
	{ return ElementAt(nIndex); }

/*============================================================================*/
// CArrayT<TYPE, ARG_TYPE> out-of-line functions

template<class TYPE, class ARG_TYPE>
CArrayT<TYPE, ARG_TYPE>::CArrayT()
{
	m_pData = NULL;
	m_nSize = m_nMaxSize = m_nGrowBy = 0;
}

template<class TYPE, class ARG_TYPE>
CArrayT<TYPE, ARG_TYPE>::~CArrayT()
{
	//ASSERT_VALID(this);

	if (m_pData != NULL)
	{
		for( int i = 0; i < m_nSize; i++ )
			(m_pData + i)->~TYPE();
		delete[] (BYTE*)m_pData;
	}
}

template<class TYPE, class ARG_TYPE>
void CArrayT<TYPE, ARG_TYPE>::SetSize(int/*INT_PTR*/ nNewSize, int/*INT_PTR*/ nGrowBy)
{
	//ASSERT_VALID(this);
	SPN_ASSERT(nNewSize >= 0);

	if (nNewSize < 0)
		return;//AfxThrowInvalidArgException();

	if (nGrowBy >= 0)
		m_nGrowBy = nGrowBy;  // set new size

	if (nNewSize == 0)
	{
		// shrink to nothing
		if (m_pData != NULL)
		{
			for( int i = 0; i < m_nSize; i++ )
				(m_pData + i)->~TYPE();
			delete[] (BYTE*)m_pData;
			m_pData = NULL;
		}
		m_nSize = m_nMaxSize = 0;
	}
	else if (m_pData == NULL)
	{
		// create buffer big enough to hold number of requested elements or
		// m_nGrowBy elements, whichever is larger.
#ifdef SIZE_T_MAX
		SPN_ASSERT(nNewSize <= SIZE_T_MAX/sizeof(TYPE));    // no overflow
#endif // 
		int nAllocSize = __max(nNewSize, m_nGrowBy);
		m_pData = (TYPE*) new BYTE[(size_t)nAllocSize * sizeof(TYPE)];
		memset((void*)m_pData, 0, (size_t)nAllocSize * sizeof(TYPE));
		for( int i = 0; i < nNewSize; i++ )
#	pragma push_macro("new")
#undef new
			::new( (void*)( m_pData + i ) ) TYPE;
#	pragma pop_macro("new")
		m_nSize = nNewSize;
		m_nMaxSize = nAllocSize;
	}
	else if (nNewSize <= m_nMaxSize)
	{
		// it fits
		if (nNewSize > m_nSize)
		{
			// initialize the new elements
			memset((void*)(m_pData + m_nSize), 0, (size_t)(nNewSize-m_nSize) * sizeof(TYPE));
			for( int i = 0; i < nNewSize-m_nSize; i++ )
#	pragma push_macro("new")
#undef new
				::new( (void*)( m_pData + m_nSize + i ) ) TYPE;
#	pragma pop_macro("new")
		}
		else if (m_nSize > nNewSize)
		{
			// destroy the old elements
			for( int i = 0; i < m_nSize-nNewSize; i++ )
				(m_pData + nNewSize + i)->~TYPE();
		}
		m_nSize = nNewSize;
	}
	else
	{
		// otherwise, grow array
		nGrowBy = m_nGrowBy;
		if (nGrowBy == 0)
		{
			// heuristically determine growth when nGrowBy == 0
			//  (this avoids heap fragmentation in many situations)
			nGrowBy = m_nSize / 8;
			nGrowBy = (nGrowBy < 4) ? 4 : ((nGrowBy > 1024) ? 1024 : nGrowBy);
		}
		int/*INT_PTR*/ nNewMax;
		if (nNewSize < m_nMaxSize + nGrowBy)
			nNewMax = m_nMaxSize + nGrowBy;  // granularity
		else
			nNewMax = nNewSize;  // no slush

		SPN_ASSERT(nNewMax >= m_nMaxSize);  // no wrap around
		
		if (nNewMax < m_nMaxSize)
			return; //AfxThrowInvalidArgException();

#ifdef SIZE_T_MAX
		SPN_ASSERT(nNewMax <= SIZE_T_MAX/sizeof(TYPE)); // no overflow
#endif // 
		TYPE* pNewData = (TYPE*) new BYTE[(size_t)nNewMax * sizeof(TYPE)];

		// copy new data from old
	#ifdef MSC_VER
		::memcpy_s(pNewData, (size_t)nNewMax * sizeof(TYPE), m_pData, (size_t)m_nSize * sizeof(TYPE));
	#else
		::memcpy(pNewData, m_pData, (size_t)m_nSize * sizeof(TYPE));//[9_19 15:44:10 ]:
	#endif // 

		// construct remaining elements
		SPN_ASSERT(nNewSize > m_nSize);
		memset((void*)(pNewData + m_nSize), 0, (size_t)(nNewSize-m_nSize) * sizeof(TYPE));
		for( int i = 0; i < nNewSize-m_nSize; i++ )
#	pragma push_macro("new")
#undef new
			::new( (void*)( pNewData + m_nSize + i ) ) TYPE;
#	pragma pop_macro("new")

		// get rid of old stuff (note: no destructors called)
		delete[] (BYTE*)m_pData;
		m_pData = pNewData;
		m_nSize = nNewSize;
		m_nMaxSize = nNewMax;
	}
}

template<class TYPE, class ARG_TYPE>
int/*INT_PTR*/ CArrayT<TYPE, ARG_TYPE>::Append(const CArrayT& src)
{
	//ASSERT_VALID(this);
	SPN_ASSERT(this != &src);   // cannot append to itself
	
	//[8_28 15:06:58 ]: 
	//if(this == &src)
	//	AfxThrowInvalidArgException();

	int/*INT_PTR*/ nOldSize = m_nSize;
	SetSize(m_nSize + src.m_nSize);
	CopyElements_<TYPE>(m_pData + nOldSize, src.m_pData, src.m_nSize);
	return nOldSize;
}

template<class TYPE, class ARG_TYPE>
void CArrayT<TYPE, ARG_TYPE>::Copy(const CArrayT& src)
{
	//ASSERT_VALID(this);
	//SPN_ASSERT(this != &src);   // cannot append to itself

	if(this != &src)
	{
		SetSize(src.m_nSize);
		CopyElements_<TYPE>(m_pData, src.m_pData, src.m_nSize);
	}
}

template<class TYPE, class ARG_TYPE>
void CArrayT<TYPE, ARG_TYPE>::FreeExtra()
{
	//ASSERT_VALID(this);

	if (m_nSize != m_nMaxSize)
	{
		// shrink to desired size
#ifdef SIZE_T_MAX
		SPN_ASSERT(m_nSize <= SIZE_T_MAX/sizeof(TYPE)); // no overflow
#endif // 
		TYPE* pNewData = NULL;
		if (m_nSize != 0)
		{
			pNewData = (TYPE*) new BYTE[m_nSize * sizeof(TYPE)];

			// copy new data from old
#if defined(__GNUC__)
			::/*ATL::Checked::*/memcpy(pNewData, /*m_nSize * sizeof(TYPE),*/
				m_pData, m_nSize * sizeof(TYPE));
#elif defined(_MSC_VER)
			::/*ATL::Checked::*/memcpy_s(pNewData, m_nSize * sizeof(TYPE),
				m_pData, m_nSize * sizeof(TYPE));
#endif // 
		}

		// get rid of old stuff (note: no destructors called)
		delete[] (BYTE*)m_pData;
		m_pData = pNewData;
		m_nMaxSize = m_nSize;
	}
}

template<class TYPE, class ARG_TYPE>
void CArrayT<TYPE, ARG_TYPE>::SetAtGrow(int/*INT_PTR*/ nIndex, const ARG_TYPE newElement)
{
	//ASSERT_VALID(this);
	SPN_ASSERT(nIndex >= 0);
	
	if (nIndex < 0)
		return;// AfxThrowInvalidArgException();

	if (nIndex >= m_nSize)
		SetSize(nIndex+1, -1);
	m_pData[nIndex] = newElement;
}

template<class TYPE, class ARG_TYPE>
void CArrayT<TYPE, ARG_TYPE>::InsertAt(int/*INT_PTR*/ nIndex, ARG_TYPE newElement, int/*INT_PTR*/ nCount /*=1*/)
{
	//ASSERT_VALID(this);
	SPN_ASSERT(nIndex >= 0);    // will expand to meet need
	SPN_ASSERT(nCount > 0);     // zero or negative size not allowed

	if(nIndex < 0 || nCount <= 0)
		return;// AfxThrowInvalidArgException();
	if (nIndex >= m_nSize)
	{
		// adding after the end of the array
		SetSize(nIndex + nCount, -1);   // grow so nIndex is valid
	}
	else
	{
		// inserting in the middle of the array
		int/*INT_PTR*/ nOldSize = m_nSize;
		SetSize(m_nSize + nCount, -1);  // grow it to new size
		// destroy intial data before copying over it
		for( int i = 0; i < nCount; i++ )
			(m_pData + nOldSize + i)->~TYPE();
		// shift old data up to fill gap
#ifdef _MSC_VER
		/*::ATL::Checked::*/memmove_s(m_pData + nIndex + nCount,
									(nOldSize-nIndex) * sizeof(TYPE),
									  m_pData + nIndex, 
									  (nOldSize-nIndex) * sizeof(TYPE));
#else
		/*::ATL::Checked::*/memmove_s(m_pData + nIndex + nCount,
									  /*(nOldSize-nIndex) * sizeof(TYPE),*/
									  m_pData + nIndex,
									  (nOldSize - nIndex) * sizeof(TYPE));
#endif // 

		// re-init slots we copied from
		memset((void*)(m_pData + nIndex), 0, (size_t)nCount * sizeof(TYPE));
		for( int i = 0; i < nCount; i++ )
#	pragma push_macro("new")
#undef new
			::new( (void*)( m_pData + nIndex + i ) ) TYPE;
#	pragma pop_macro("new")
	}

	// insert new value in the gap
	SPN_ASSERT(nIndex + nCount <= m_nSize);
	while (nCount--)
		m_pData[nIndex++] = newElement;
}

template<class TYPE, class ARG_TYPE>
void CArrayT<TYPE, ARG_TYPE>::RemoveAt(int/*INT_PTR*/ nIndex, int/*INT_PTR*/ nCount)
{
	//ASSERT_VALID(this);
	SPN_ASSERT(nIndex >= 0);
	SPN_ASSERT(nCount >= 0);
	int/*INT_PTR*/ nUpperBound = nIndex + nCount;
	SPN_ASSERT(nUpperBound <= m_nSize && nUpperBound >= nIndex && nUpperBound >= nCount);

	if(nIndex < 0 || nCount < 0 || (nUpperBound > m_nSize) || (nUpperBound < nIndex) || (nUpperBound < nCount))
		return;// AfxThrowInvalidArgException();

	// just remove a range
	int/*INT_PTR*/ nMoveCount = m_nSize - (nUpperBound);
	for( int i = 0; i < nCount; i++ )
		(m_pData + nIndex + i)->~TYPE();
	if (nMoveCount)
	{
#ifdef _MSC_VER
		::/*ATL::Checked::*/memmove_s(m_pData + nIndex,
									  (size_t)nMoveCount * sizeof(TYPE),
									  m_pData + nUpperBound, 
									  (size_t)nMoveCount * sizeof(TYPE));
#else
		::/*ATL::Checked::*/memmove_s(m_pData + nIndex,
									  //(size_t)nMoveCount * sizeof(TYPE),
									  m_pData + nUpperBound, 
									  (size_t)nMoveCount * sizeof(TYPE));
#endif // 
	}
	m_nSize -= nCount;
}

template<class TYPE, class ARG_TYPE>
void CArrayT<TYPE, ARG_TYPE>::InsertAt(int/*INT_PTR*/ nStartIndex, CArrayT* pNewArray)
{
	//ASSERT_VALID(this);
	SPN_ASSERT(pNewArray != NULL);
	//ASSERT_VALID(pNewArray);
	SPN_ASSERT(nStartIndex >= 0);

	if(pNewArray == NULL || nStartIndex < 0)
		return;// AfxThrowInvalidArgException();

	if (pNewArray->GetSize() > 0)
	{
		InsertAt(nStartIndex, pNewArray->GetAt(0), pNewArray->GetSize());
		for (int/*INT_PTR*/ i = 0; i < pNewArray->GetSize(); i++)
			SetAt(nStartIndex + i, pNewArray->GetAt(i));
	}
}

//
//template<class TYPE, class ARG_TYPE>
//void CArrayT<TYPE, ARG_TYPE>::Serialize(CArchive& ar)
//{
//	//ASSERT_VALID(this);
//
//	CObject::Serialize(ar);
//	if (ar.IsStoring())
//	{
//		ar.WriteCount(m_nSize);
//	}
//	else
//	{
//		DWORD_PTR nOldSize = ar.ReadCount();
//		SetSize(nOldSize, -1);
//	}
//	SerializeElements<TYPE>(ar, m_pData, m_nSize);
//}

#ifdef _DEBUG
//
//template<class TYPE, class ARG_TYPE>
//void CArrayT<TYPE, ARG_TYPE>::Dump(CDumpContext& dc) const
//{
//	CObject::Dump(dc);
//
//	dc << "with " << m_nSize << " elements";
//	if (dc.GetDepth() > 0)
//	{
//		dc << "\n";
//		DumpElements<TYPE>(dc, m_pData, m_nSize);
//	}
//
//	dc << "\n";
//}
//
//template<class TYPE, class ARG_TYPE>
//void CArrayT<TYPE, ARG_TYPE>::AssertValid() const
//{
//	CObject::AssertValid();
//
//	if (m_pData == NULL)
//	{
//		SPN_ASSERT(m_nSize == 0);
//		SPN_ASSERT(m_nMaxSize == 0);
//	}
//	else
//	{
//		SPN_ASSERT(m_nSize >= 0);
//		SPN_ASSERT(m_nMaxSize >= 0);
//		SPN_ASSERT(m_nSize <= m_nMaxSize);
//		SPN_ASSERT(AfxIsValidAddress(m_pData, m_nMaxSize * sizeof(TYPE)));
//	}
//}
#endif //  //_DEBUG

///*============================================================================*/
//// CList<TYPE, ARG_TYPE>
//
//template<class TYPE, class ARG_TYPE = const TYPE&>
//class CList : public CObject
//{
//protected:
//	struct CNode
//	{
//		CNode* pNext;
//		CNode* pPrev;
//		TYPE data;
//	};
//public:
//// Construction
//	explicit CList(int/*INT_PTR*/ nBlockSize = 10);
//
//// Attributes (head and tail)
//	// count of elements
//	int/*INT_PTR*/ GetCount() const;
//	int/*INT_PTR*/ GetSize() const;
//	BOOL IsEmpty() const;
//
//	// peek at head or tail
//	TYPE& GetHead();
//	const TYPE& GetHead() const;
//	TYPE& GetTail();
//	const TYPE& GetTail() const;
//
//// Operations
//	// get head or tail (and remove it) - don't call on empty list !
//	TYPE RemoveHead();
//	TYPE RemoveTail();
//
//	// add before head or after tail
//	POSITION AddHead(ARG_TYPE newElement);
//	POSITION AddTail(ARG_TYPE newElement);
//
//	// add another list of elements before head or after tail
//	void AddHead(CList* pNewList);
//	void AddTail(CList* pNewList);
//
//	// remove all elements
//	void RemoveAll();
//
//	// iteration
//	POSITION GetHeadPosition() const;
//	POSITION GetTailPosition() const;
//	TYPE& GetNext(POSITION& rPosition); // return *Position++
//	const TYPE& GetNext(POSITION& rPosition) const; // return *Position++
//	TYPE& GetPrev(POSITION& rPosition); // return *Position--
//	const TYPE& GetPrev(POSITION& rPosition) const; // return *Position--
//
//	// getting/modifying an element at a given position
//	TYPE& GetAt(POSITION position);
//	const TYPE& GetAt(POSITION position) const;
//	void SetAt(POSITION pos, ARG_TYPE newElement);
//	void RemoveAt(POSITION position);
//
//	// inserting before or after a given position
//	POSITION InsertBefore(POSITION position, ARG_TYPE newElement);
//	POSITION InsertAfter(POSITION position, ARG_TYPE newElement);
//
//	// helper functions (note: O(n) speed)
//	POSITION Find(ARG_TYPE searchValue, POSITION startAfter = NULL) const;
//		// defaults to starting at the HEAD, return NULL if not found
//	POSITION FindIndex(int/*INT_PTR*/ nIndex) const;
//		// get the 'nIndex'th element (may return NULL)
//
//// Implementation
//protected:
//	CNode* m_pNodeHead;
//	CNode* m_pNodeTail;
//	int/*INT_PTR*/ m_nCount;
//	CNode* m_pNodeFree;
//	struct CPlex* m_pBlocks;
//	int/*INT_PTR*/ m_nBlockSize;
//
//	CNode* NewNode(CNode*, CNode*);
//	void FreeNode(CNode*);
//
//public:
//	virtual ~CList();
//	void Serialize(CArchive&);
//#ifdef _DEBUG
//	void Dump(CDumpContext&) const;
//	void AssertValid() const;
//#endif // 
//};
//
///*============================================================================*/
//// CList<TYPE, ARG_TYPE> inline functions
//
//template<class TYPE, class ARG_TYPE>
//inline int/*INT_PTR*/ CList<TYPE, ARG_TYPE>::GetCount() const
//	{ return m_nCount; }
//template<class TYPE, class ARG_TYPE>
//inline int/*INT_PTR*/ CList<TYPE, ARG_TYPE>::GetSize() const
//	{ return m_nCount; }
//template<class TYPE, class ARG_TYPE>
//inline BOOL CList<TYPE, ARG_TYPE>::IsEmpty() const
//	{ return m_nCount == 0; }
//template<class TYPE, class ARG_TYPE>
//inline TYPE& CList<TYPE, ARG_TYPE>::GetHead()
//	{ SPN_ASSERT(m_pNodeHead != NULL);
//		return m_pNodeHead->data; }
//template<class TYPE, class ARG_TYPE>
//inline const TYPE& CList<TYPE, ARG_TYPE>::GetHead() const
//	{ SPN_ASSERT(m_pNodeHead != NULL);
//		return m_pNodeHead->data; }
//template<class TYPE, class ARG_TYPE>
//inline TYPE& CList<TYPE, ARG_TYPE>::GetTail()
//	{ SPN_ASSERT(m_pNodeTail != NULL);
//		return m_pNodeTail->data; }
//template<class TYPE, class ARG_TYPE>
//inline const TYPE& CList<TYPE, ARG_TYPE>::GetTail() const
//	{ SPN_ASSERT(m_pNodeTail != NULL);
//		return m_pNodeTail->data; }
//template<class TYPE, class ARG_TYPE>
//inline POSITION CList<TYPE, ARG_TYPE>::GetHeadPosition() const
//	{ return (POSITION) m_pNodeHead; }
//template<class TYPE, class ARG_TYPE>
//inline POSITION CList<TYPE, ARG_TYPE>::GetTailPosition() const
//	{ return (POSITION) m_pNodeTail; }
//template<class TYPE, class ARG_TYPE>
//inline TYPE& CList<TYPE, ARG_TYPE>::GetNext(POSITION& rPosition) // return *Position++
//	{ CNode* pNode = (CNode*) rPosition;
//		SPN_ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
//		rPosition = (POSITION) pNode->pNext;
//		return pNode->data; }
//template<class TYPE, class ARG_TYPE>
//inline const TYPE& CList<TYPE, ARG_TYPE>::GetNext(POSITION& rPosition) const // return *Position++
//	{ CNode* pNode = (CNode*) rPosition;
//		SPN_ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
//		rPosition = (POSITION) pNode->pNext;
//		return pNode->data; }
//template<class TYPE, class ARG_TYPE>
//inline TYPE& CList<TYPE, ARG_TYPE>::GetPrev(POSITION& rPosition) // return *Position--
//	{ CNode* pNode = (CNode*) rPosition;
//		SPN_ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
//		rPosition = (POSITION) pNode->pPrev;
//		return pNode->data; }
//template<class TYPE, class ARG_TYPE>
//inline const TYPE& CList<TYPE, ARG_TYPE>::GetPrev(POSITION& rPosition) const // return *Position--
//	{ CNode* pNode = (CNode*) rPosition;
//		SPN_ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
//		rPosition = (POSITION) pNode->pPrev;
//		return pNode->data; }
//template<class TYPE, class ARG_TYPE>
//inline TYPE& CList<TYPE, ARG_TYPE>::GetAt(POSITION position)
//	{ CNode* pNode = (CNode*) position;
//		SPN_ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
//		return pNode->data; }
//template<class TYPE, class ARG_TYPE>
//inline const TYPE& CList<TYPE, ARG_TYPE>::GetAt(POSITION position) const
//	{ CNode* pNode = (CNode*) position;
//		SPN_ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
//		return pNode->data; }
//template<class TYPE, class ARG_TYPE>
//inline void CList<TYPE, ARG_TYPE>::SetAt(POSITION pos, ARG_TYPE newElement)
//	{ CNode* pNode = (CNode*) pos;
//		SPN_ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
//		pNode->data = newElement; }
//
//template<class TYPE, class ARG_TYPE>
//CList<TYPE, ARG_TYPE>::CList(int/*INT_PTR*/ nBlockSize)
//{
//	SPN_ASSERT(nBlockSize > 0);
//
//	m_nCount = 0;
//	m_pNodeHead = m_pNodeTail = m_pNodeFree = NULL;
//	m_pBlocks = NULL;
//	m_nBlockSize = nBlockSize;
//}
//
//template<class TYPE, class ARG_TYPE>
//void CList<TYPE, ARG_TYPE>::RemoveAll()
//{
//	//ASSERT_VALID(this);
//
//	// destroy elements
//	CNode* pNode;
//	for (pNode = m_pNodeHead; pNode != NULL; pNode = pNode->pNext)
//		pNode->data.~TYPE();
//
//	m_nCount = 0;
//	m_pNodeHead = m_pNodeTail = m_pNodeFree = NULL;
//	m_pBlocks->FreeDataChain();
//	m_pBlocks = NULL;
//}
//
//template<class TYPE, class ARG_TYPE>
//CList<TYPE, ARG_TYPE>::~CList()
//{
//	RemoveAll();
//	SPN_ASSERT(m_nCount == 0);
//}
//
///*============================================================================*/
//// Node helpers
////
//// Implementation note: CNode's are stored in CPlex blocks and
////  chained together. Free blocks are maintained in a singly linked list
////  using the 'pNext' member of CNode with 'm_pNodeFree' as the head.
////  Used blocks are maintained in a doubly linked list using both 'pNext'
////  and 'pPrev' as links and 'm_pNodeHead' and 'm_pNodeTail'
////   as the head/tail.
////
//// We never free a CPlex block unless the List is destroyed or RemoveAll()
////  is used - so the total number of CPlex blocks may grow large depending
////  on the maximum past size of the list.
////
//
//template<class TYPE, class ARG_TYPE>
//typename CList<TYPE, ARG_TYPE>::CNode*
//CList<TYPE, ARG_TYPE>::NewNode(CNode* pPrev, CNode* pNext)
//{
//	if (m_pNodeFree == NULL)
//	{
//		// add another block
//		CPlex* pNewBlock = CPlex::Create(m_pBlocks, m_nBlockSize,
//				 sizeof(CNode));
//
//		// chain them into free list
//		CNode* pNode = (CNode*) pNewBlock->data();
//		// free in reverse order to make it easier to debug
//		pNode += m_nBlockSize - 1;
//		for (int/*INT_PTR*/ i = m_nBlockSize-1; i >= 0; i--, pNode--)
//		{
//			pNode->pNext = m_pNodeFree;
//			m_pNodeFree = pNode;
//		}
//	}
//	SPN_ASSERT(m_pNodeFree != NULL);  // we must have something
//
//	CList::CNode* pNode = m_pNodeFree;
//	m_pNodeFree = m_pNodeFree->pNext;
//	pNode->pPrev = pPrev;
//	pNode->pNext = pNext;
//	m_nCount++;
//	SPN_ASSERT(m_nCount > 0);  // make sure we don't overflow
//
//#	pragma push_macro("new")
//#undef new
//	::new( (void*)( &pNode->data ) ) TYPE;
//#	pragma pop_macro("new")
//	return pNode;
//}
//
//template<class TYPE, class ARG_TYPE>
//void CList<TYPE, ARG_TYPE>::FreeNode(CNode* pNode)
//{
//	pNode->data.~TYPE();
//	pNode->pNext = m_pNodeFree;
//	m_pNodeFree = pNode;
//	m_nCount--;
//	SPN_ASSERT(m_nCount >= 0);  // make sure we don't underflow
//
//	// if no more elements, cleanup completely
//	if (m_nCount == 0)
//		RemoveAll();
//}
//
//template<class TYPE, class ARG_TYPE>
//POSITION CList<TYPE, ARG_TYPE>::AddHead(ARG_TYPE newElement)
//{
//	//ASSERT_VALID(this);
//
//	CNode* pNewNode = NewNode(NULL, m_pNodeHead);
//	pNewNode->data = newElement;
//	if (m_pNodeHead != NULL)
//		m_pNodeHead->pPrev = pNewNode;
//	else
//		m_pNodeTail = pNewNode;
//	m_pNodeHead = pNewNode;
//	return (POSITION) pNewNode;
//}
//
//template<class TYPE, class ARG_TYPE>
//POSITION CList<TYPE, ARG_TYPE>::AddTail(ARG_TYPE newElement)
//{
//	//ASSERT_VALID(this);
//
//	CNode* pNewNode = NewNode(m_pNodeTail, NULL);
//	pNewNode->data = newElement;
//	if (m_pNodeTail != NULL)
//		m_pNodeTail->pNext = pNewNode;
//	else
//		m_pNodeHead = pNewNode;
//	m_pNodeTail = pNewNode;
//	return (POSITION) pNewNode;
//}
//
//template<class TYPE, class ARG_TYPE>
//void CList<TYPE, ARG_TYPE>::AddHead(CList* pNewList)
//{
//	//ASSERT_VALID(this);
//
//	SPN_ASSERT(pNewList != NULL);
//	ASSERT_VALID(pNewList);
//
//	// add a list of same elements to head (maintain order)
//	POSITION pos = pNewList->GetTailPosition();
//	while (pos != NULL)
//		AddHead(pNewList->GetPrev(pos));
//}
//
//template<class TYPE, class ARG_TYPE>
//void CList<TYPE, ARG_TYPE>::AddTail(CList* pNewList)
//{
//	//ASSERT_VALID(this);
//	SPN_ASSERT(pNewList != NULL);
//	ASSERT_VALID(pNewList);
//
//	// add a list of same elements
//	POSITION pos = pNewList->GetHeadPosition();
//	while (pos != NULL)
//		AddTail(pNewList->GetNext(pos));
//}
//
//template<class TYPE, class ARG_TYPE>
//TYPE CList<TYPE, ARG_TYPE>::RemoveHead()
//{
//	//ASSERT_VALID(this);
//	SPN_ASSERT(m_pNodeHead != NULL);  // don't call on empty list !!!
//	SPN_ASSERT(AfxIsValidAddress(m_pNodeHead, sizeof(CNode)));
//
//	CNode* pOldNode = m_pNodeHead;
//	TYPE returnValue = pOldNode->data;
//
//	m_pNodeHead = pOldNode->pNext;
//	if (m_pNodeHead != NULL)
//		m_pNodeHead->pPrev = NULL;
//	else
//		m_pNodeTail = NULL;
//	FreeNode(pOldNode);
//	return returnValue;
//}
//
//template<class TYPE, class ARG_TYPE>
//TYPE CList<TYPE, ARG_TYPE>::RemoveTail()
//{
//	//ASSERT_VALID(this);
//	SPN_ASSERT(m_pNodeTail != NULL);  // don't call on empty list !!!
//	SPN_ASSERT(AfxIsValidAddress(m_pNodeTail, sizeof(CNode)));
//
//	CNode* pOldNode = m_pNodeTail;
//	TYPE returnValue = pOldNode->data;
//
//	m_pNodeTail = pOldNode->pPrev;
//	if (m_pNodeTail != NULL)
//		m_pNodeTail->pNext = NULL;
//	else
//		m_pNodeHead = NULL;
//	FreeNode(pOldNode);
//	return returnValue;
//}
//
//template<class TYPE, class ARG_TYPE>
//POSITION CList<TYPE, ARG_TYPE>::InsertBefore(POSITION position, ARG_TYPE newElement)
//{
//	//ASSERT_VALID(this);
//
//	if (position == NULL)
//		return AddHead(newElement); // insert before nothing -> head of the list
//
//	// Insert it before position
//	CNode* pOldNode = (CNode*) position;
//	CNode* pNewNode = NewNode(pOldNode->pPrev, pOldNode);
//	pNewNode->data = newElement;
//
//	if (pOldNode->pPrev != NULL)
//	{
//		SPN_ASSERT(AfxIsValidAddress(pOldNode->pPrev, sizeof(CNode)));
//		pOldNode->pPrev->pNext = pNewNode;
//	}
//	else
//	{
//		SPN_ASSERT(pOldNode == m_pNodeHead);
//		m_pNodeHead = pNewNode;
//	}
//	pOldNode->pPrev = pNewNode;
//	return (POSITION) pNewNode;
//}
//
//template<class TYPE, class ARG_TYPE>
//POSITION CList<TYPE, ARG_TYPE>::InsertAfter(POSITION position, ARG_TYPE newElement)
//{
//	//ASSERT_VALID(this);
//
//	if (position == NULL)
//		return AddTail(newElement); // insert after nothing -> tail of the list
//
//	// Insert it before position
//	CNode* pOldNode = (CNode*) position;
//	SPN_ASSERT(AfxIsValidAddress(pOldNode, sizeof(CNode)));
//	CNode* pNewNode = NewNode(pOldNode, pOldNode->pNext);
//	pNewNode->data = newElement;
//
//	if (pOldNode->pNext != NULL)
//	{
//		SPN_ASSERT(AfxIsValidAddress(pOldNode->pNext, sizeof(CNode)));
//		pOldNode->pNext->pPrev = pNewNode;
//	}
//	else
//	{
//		SPN_ASSERT(pOldNode == m_pNodeTail);
//		m_pNodeTail = pNewNode;
//	}
//	pOldNode->pNext = pNewNode;
//	return (POSITION) pNewNode;
//}
//
//template<class TYPE, class ARG_TYPE>
//void CList<TYPE, ARG_TYPE>::RemoveAt(POSITION position)
//{
//	//ASSERT_VALID(this);
//
//	CNode* pOldNode = (CNode*) position;
//	SPN_ASSERT(AfxIsValidAddress(pOldNode, sizeof(CNode)));
//
//	// remove pOldNode from list
//	if (pOldNode == m_pNodeHead)
//	{
//		m_pNodeHead = pOldNode->pNext;
//	}
//	else
//	{
//		SPN_ASSERT(AfxIsValidAddress(pOldNode->pPrev, sizeof(CNode)));
//		pOldNode->pPrev->pNext = pOldNode->pNext;
//	}
//	if (pOldNode == m_pNodeTail)
//	{
//		m_pNodeTail = pOldNode->pPrev;
//	}
//	else
//	{
//		SPN_ASSERT(AfxIsValidAddress(pOldNode->pNext, sizeof(CNode)));
//		pOldNode->pNext->pPrev = pOldNode->pPrev;
//	}
//	FreeNode(pOldNode);
//}
//
//template<class TYPE, class ARG_TYPE>
//POSITION CList<TYPE, ARG_TYPE>::FindIndex(int/*INT_PTR*/ nIndex) const
//{
//	//ASSERT_VALID(this);
//
//	if (nIndex >= m_nCount || nIndex < 0)
//		return NULL;  // went too far
//
//	CNode* pNode = m_pNodeHead;
//	while (nIndex--)
//	{
//		SPN_ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
//		pNode = pNode->pNext;
//	}
//	return (POSITION) pNode;
//}
//
//template<class TYPE, class ARG_TYPE>
//POSITION CList<TYPE, ARG_TYPE>::Find(ARG_TYPE searchValue, POSITION startAfter) const
//{
//	//ASSERT_VALID(this);
//
//	CNode* pNode = (CNode*) startAfter;
//	if (pNode == NULL)
//	{
//		pNode = m_pNodeHead;  // start at head
//	}
//	else
//	{
//		SPN_ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
//		pNode = pNode->pNext;  // start after the one specified
//	}
//
//	for (; pNode != NULL; pNode = pNode->pNext)
//		if (CompareElements_<TYPE>(&pNode->data, &searchValue))
//			return (POSITION)pNode;
//	return NULL;
//}
//
//template<class TYPE, class ARG_TYPE>
//void CList<TYPE, ARG_TYPE>::Serialize(CArchive& ar)
//{
//	//ASSERT_VALID(this);
//
//	CObject::Serialize(ar);
//
//	if (ar.IsStoring())
//	{
//		ar.WriteCount(m_nCount);
//		for (CNode* pNode = m_pNodeHead; pNode != NULL; pNode = pNode->pNext)
//		{
//			SPN_ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
//			TYPE* pData;
//			/* 
//			 * in some cases the & operator might be overloaded, and we cannot use it to obtain
//			 * the address of a given object.  We then use the following trick to get the address
//			 */
//			pData = reinterpret_cast< TYPE* >( &reinterpret_cast< int& >( static_cast< TYPE& >( pNode->data ) ) );
//			SerializeElements<TYPE>(ar, pData, 1);
//		}
//	}
//	else
//	{
//		DWORD_PTR nNewCount = ar.ReadCount();
//		while (nNewCount--)
//		{
//			TYPE newData[1];
//			SerializeElements<TYPE>(ar, newData, 1);
//			AddTail(newData[0]);
//		}
//	}
//}
//
//#ifdef _DEBUG
//template<class TYPE, class ARG_TYPE>
//void CList<TYPE, ARG_TYPE>::Dump(CDumpContext& dc) const
//{
//	CObject::Dump(dc);
//
//	dc << "with " << m_nCount << " elements";
//	if (dc.GetDepth() > 0)
//	{
//		POSITION pos = GetHeadPosition();
//		while (pos != NULL)
//		{
//			TYPE temp[1];
//			temp[0] = ((CList*)this)->GetNext(pos);
//			dc << "\n";
//			DumpElements<TYPE>(dc, temp, 1);
//		}
//	}
//
//	dc << "\n";
//}
//
//template<class TYPE, class ARG_TYPE>
//void CList<TYPE, ARG_TYPE>::AssertValid() const
//{
//	CObject::AssertValid();
//
//	if (m_nCount == 0)
//	{
//		// empty list
//		SPN_ASSERT(m_pNodeHead == NULL);
//		SPN_ASSERT(m_pNodeTail == NULL);
//	}
//	else
//	{
//		// non-empty list
//		SPN_ASSERT(AfxIsValidAddress(m_pNodeHead, sizeof(CNode)));
//		SPN_ASSERT(AfxIsValidAddress(m_pNodeTail, sizeof(CNode)));
//	}
//}
//#endif //  //_DEBUG

///*============================================================================*/
//// CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//class CMap : public CObject
//{
//public:
//	// CPair
//	struct CPair
//	{
//		const KEY key;
//		VALUE value;
//	protected:
//		CPair( ARG_KEY keyval ) : key( keyval )	{}
//	};
//
//protected:
//	// Association
//	class CAssoc : public CPair
//	{
//		friend class CMap<KEY,ARG_KEY,VALUE,ARG_VALUE>;
//		CAssoc* pNext;
//		UINT nHashValue;  // needed for efficient iteration
//	public:
//		CAssoc( ARG_KEY key ) : CPair( key ) {}
//	};
//
//public:
//// Construction
//	explicit CMap(int/*INT_PTR*/ nBlockSize = 10);
//
//// Attributes
//	// number of elements
//	int/*INT_PTR*/ GetCount() const;
//	int/*INT_PTR*/ GetSize() const;
//	BOOL IsEmpty() const;
//
//	// Lookup
//	BOOL Lookup(ARG_KEY key, VALUE& rValue) const;
//	const CPair *PLookup(ARG_KEY key) const;
//	CPair *PLookup(ARG_KEY key);
//
//// Operations
//	// Lookup and add if not there
//	VALUE& operator[](ARG_KEY key);
//
//	// add a new (key, value) pair
//	void SetAt(ARG_KEY key, ARG_VALUE newValue);
//
//	// removing existing (key, ?) pair
//	BOOL RemoveKey(ARG_KEY key);
//	void RemoveAll();
//
//	// iterating all (key, value) pairs
//	POSITION GetStartPosition() const;
//
//	const CPair *PGetFirstAssoc() const;
//	CPair *PGetFirstAssoc();
//
//	void GetNextAssoc(POSITION& rNextPosition, KEY& rKey, VALUE& rValue) const;
//
//	const CPair *PGetNextAssoc(const CPair *pAssocRet) const;
//	CPair *PGetNextAssoc(const CPair *pAssocRet);
//
//	// advanced features for derived classes
//	UINT GetHashTableSize() const;
//	void InitHashTable(UINT hashSize, BOOL bAllocNow = TRUE);
//
//// Implementation
//protected:
//	CAssoc** m_pHashTable;
//	UINT m_nHashTableSize;
//	int/*INT_PTR*/ m_nCount;
//	CAssoc* m_pFreeList;
//	struct CPlex* m_pBlocks;
//	int/*INT_PTR*/ m_nBlockSize;
//
//	CAssoc* NewAssoc(ARG_KEY key);
//	void FreeAssoc(CAssoc*);
//	CAssoc* GetAssocAt(ARG_KEY, UINT&, UINT&) const;
//
//public:
//	virtual ~CMap();
//	void Serialize(CArchive&);
//#ifdef _DEBUG
//	void Dump(CDumpContext&) const;
//	void AssertValid() const;
//#endif // 
//};
//
///*============================================================================*/
//// CMap<KEY, ARG_KEY, VALUE, ARG_VALUE> inline functions
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//inline int/*INT_PTR*/ CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::GetCount() const
//	{ return m_nCount; }
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//inline int/*INT_PTR*/ CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::GetSize() const
//	{ return m_nCount; }
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//inline BOOL CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::IsEmpty() const
//	{ return m_nCount == 0; }
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//inline void CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::SetAt(ARG_KEY key, ARG_VALUE newValue)
//	{ (*this)[key] = newValue; }
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//inline POSITION CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::GetStartPosition() const
//	{ return (m_nCount == 0) ? NULL : BEFORE_START_POSITION; }
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//const typename CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::CPair* CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::PGetFirstAssoc() const
//{ 
//	//ASSERT_VALID(this);
//	if(m_nCount == 0) return NULL;
//
//	AFXASSUME(m_pHashTable != NULL);  // never call on empty map
//
//	CAssoc* pAssocRet = (CAssoc*)BEFORE_START_POSITION;
//
//	// find the first association
//	for (UINT nBucket = 0; nBucket < m_nHashTableSize; nBucket++)
//		if ((pAssocRet = m_pHashTable[nBucket]) != NULL)
//			break;
//	SPN_ASSERT(pAssocRet != NULL);  // must find something
//
//	return pAssocRet;
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//typename CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::CPair* CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::PGetFirstAssoc()
//{ 
//	//ASSERT_VALID(this);
//	if(m_nCount == 0) return NULL;
//
//	AFXASSUME(m_pHashTable != NULL);  // never call on empty map
//
//	CAssoc* pAssocRet = (CAssoc*)BEFORE_START_POSITION;
//
//	// find the first association
//	for (UINT nBucket = 0; nBucket < m_nHashTableSize; nBucket++)
//		if ((pAssocRet = m_pHashTable[nBucket]) != NULL)
//			break;
//	SPN_ASSERT(pAssocRet != NULL);  // must find something
//
//	return pAssocRet;
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//inline UINT CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::GetHashTableSize() const
//	{ return m_nHashTableSize; }
//
///*============================================================================*/
//// CMap<KEY, ARG_KEY, VALUE, ARG_VALUE> out-of-line functions
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::CMap(int/*INT_PTR*/ nBlockSize)
//{
//	SPN_ASSERT(nBlockSize > 0);
//
//	m_pHashTable = NULL;
//	m_nHashTableSize = 17;  // default size
//	m_nCount = 0;
//	m_pFreeList = NULL;
//	m_pBlocks = NULL;
//	m_nBlockSize = nBlockSize;
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//void CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::InitHashTable(
//	UINT nHashSize, BOOL bAllocNow)
////
//// Used to force allocation of a hash table or to override the default
////   hash table size of (which is fairly small)
//{
//	//ASSERT_VALID(this);
//	SPN_ASSERT(m_nCount == 0);
//	SPN_ASSERT(nHashSize > 0);
//
//	if (m_pHashTable != NULL)
//	{
//		// free hash table
//		delete[] m_pHashTable;
//		m_pHashTable = NULL;
//	}
//
//	if (bAllocNow)
//	{
//		m_pHashTable = new CAssoc* [nHashSize];
//		SPN_ASSERT(m_pHashTable != NULL);
//		memset(m_pHashTable, 0, sizeof(CAssoc*) * nHashSize);
//	}
//	m_nHashTableSize = nHashSize;
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//void CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::RemoveAll()
//{
//	//ASSERT_VALID(this);
//
//	if (m_pHashTable != NULL)
//	{
//		// destroy elements (values and keys)
//		for (UINT nHash = 0; nHash < m_nHashTableSize; nHash++)
//		{
//			CAssoc* pAssoc;
//			for (pAssoc = m_pHashTable[nHash]; pAssoc != NULL;
//			  pAssoc = pAssoc->pNext)
//			{
//				pAssoc->CAssoc::~CAssoc();
//			}
//		}
//		
//		// free hash table
//		delete[] m_pHashTable;
//		m_pHashTable = NULL;
//	}
//	
//	m_nCount = 0;
//	m_pFreeList = NULL;
//	m_pBlocks->FreeDataChain();
//	m_pBlocks = NULL;
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::~CMap()
//{
//	RemoveAll();
//	SPN_ASSERT(m_nCount == 0);
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//typename CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::CAssoc*
//CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::NewAssoc(ARG_KEY key)
//{
//	if (m_pFreeList == NULL)
//	{
//		// add another block
//		CPlex* newBlock = CPlex::Create(m_pBlocks, m_nBlockSize, sizeof(CMap::CAssoc));
//		// chain them into free list
//		CMap::CAssoc* pAssoc = (CMap::CAssoc*) newBlock->data();
//		// free in reverse order to make it easier to debug
//		pAssoc += m_nBlockSize - 1;
//		for (int/*INT_PTR*/ i = m_nBlockSize-1; i >= 0; i--, pAssoc--)
//		{
//			pAssoc->pNext = m_pFreeList;
//			m_pFreeList = pAssoc;
//		}
//	}
//	SPN_ASSERT(m_pFreeList != NULL);  // we must have something
//
//	CMap::CAssoc* pAssoc = m_pFreeList;
//
//	// zero the memory
//	CMap::CAssoc* pTemp = pAssoc->pNext;
//	memset( pAssoc, 0, sizeof(CMap::CAssoc) );
//	pAssoc->pNext = pTemp;
//
//	m_pFreeList = m_pFreeList->pNext;
//	m_nCount++;
//	SPN_ASSERT(m_nCount > 0);  // make sure we don't overflow
//#	pragma push_macro("new")
//#undef new
//	::new(pAssoc) CMap::CAssoc(key);
//#	pragma pop_macro("new")
//	return pAssoc;
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//void CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::FreeAssoc(CAssoc* pAssoc)
//{
//	pAssoc->CAssoc::~CAssoc();
//	pAssoc->pNext = m_pFreeList;
//	m_pFreeList = pAssoc;
//	m_nCount--;
//	SPN_ASSERT(m_nCount >= 0);  // make sure we don't underflow
//
//	// if no more elements, cleanup completely
//	if (m_nCount == 0)
//		RemoveAll();
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//typename CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::CAssoc*
//CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::GetAssocAt(ARG_KEY key, UINT& nHashBucket, UINT& nHashValue) const
//// find association (or return NULL)
//{
//	nHashValue = HashKey_<ARG_KEY>(key);
//	nHashBucket = nHashValue % m_nHashTableSize;
//
//	if (m_pHashTable == NULL)
//		return NULL;
//
//	// see if it exists
//	CAssoc* pAssoc;
//	for (pAssoc = m_pHashTable[nHashBucket]; pAssoc != NULL; pAssoc = pAssoc->pNext)
//	{
//		if (pAssoc->nHashValue == nHashValue && CompareElements_(&pAssoc->key, &key))
//			return pAssoc;
//	}
//	return NULL;
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//BOOL CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::Lookup(ARG_KEY key, VALUE& rValue) const
//{
//	//ASSERT_VALID(this);
//
//	UINT nHashBucket, nHashValue;
//	CAssoc* pAssoc = GetAssocAt(key, nHashBucket, nHashValue);
//	if (pAssoc == NULL)
//		return FALSE;  // not in map
//
//	rValue = pAssoc->value;
//	return TRUE;
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//const typename CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::CPair* CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::PLookup(ARG_KEY key) const
//{
//	//ASSERT_VALID(this);
//
//	UINT nHashBucket, nHashValue;
//	CAssoc* pAssoc = GetAssocAt(key, nHashBucket, nHashValue);
//	return pAssoc;
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//typename CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::CPair* CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::PLookup(ARG_KEY key)
//{
//	//ASSERT_VALID(this);
//
//	UINT nHashBucket, nHashValue;
//	CAssoc* pAssoc = GetAssocAt(key, nHashBucket, nHashValue);
//	return pAssoc;
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//VALUE& CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::operator[](ARG_KEY key)
//{
//	//ASSERT_VALID(this);
//
//	UINT nHashBucket, nHashValue;
//	CAssoc* pAssoc;
//	if ((pAssoc = GetAssocAt(key, nHashBucket, nHashValue)) == NULL)
//	{
//		if (m_pHashTable == NULL)
//			InitHashTable(m_nHashTableSize);
//
//		SPN_ASSERT(m_pHashTable);
//		// it doesn't exist, add a new Association
//		pAssoc = NewAssoc(key);
//		pAssoc->nHashValue = nHashValue;
//		//'pAssoc->value' is a constructed object, nothing more
//
//		// put into hash table
//		pAssoc->pNext = m_pHashTable[nHashBucket];
//		m_pHashTable[nHashBucket] = pAssoc;
//	}
//	return pAssoc->value;  // return new reference
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//BOOL CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::RemoveKey(ARG_KEY key)
//// remove key - return TRUE if removed
//{
//	//ASSERT_VALID(this);
//
//	if (m_pHashTable == NULL)
//		return FALSE;  // nothing in the table
//
//	UINT nHashValue;
//	CAssoc** ppAssocPrev;
//	nHashValue = HashKey_<ARG_KEY>(key);
//	ppAssocPrev = &m_pHashTable[nHashValue%m_nHashTableSize];
//
//	CAssoc* pAssoc;
//	for (pAssoc = *ppAssocPrev; pAssoc != NULL; pAssoc = pAssoc->pNext)
//	{
//		if ((pAssoc->nHashValue == nHashValue) && CompareElements_(&pAssoc->key, &key))
//		{
//			// remove it
//			*ppAssocPrev = pAssoc->pNext;  // remove from list
//			FreeAssoc(pAssoc);
//			return TRUE;
//		}
//		ppAssocPrev = &pAssoc->pNext;
//	}
//	return FALSE;  // not found
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//void CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::GetNextAssoc(POSITION& rNextPosition,
//	KEY& rKey, VALUE& rValue) const
//{
//	//ASSERT_VALID(this);
//	SPN_ASSERT(m_pHashTable != NULL);  // never call on empty map
//
//	CAssoc* pAssocRet = (CAssoc*)rNextPosition;
//	SPN_ASSERT(pAssocRet != NULL);
//
//	if (pAssocRet == (CAssoc*) BEFORE_START_POSITION)
//	{
//		// find the first association
//		for (UINT nBucket = 0; nBucket < m_nHashTableSize; nBucket++)
//		{
//			if ((pAssocRet = m_pHashTable[nBucket]) != NULL)
//			{
//				break;
//			}
//		}
//		SPN_ASSERT(pAssocRet != NULL);  // must find something
//	}
//
//	// find next association
//	SPN_ASSERT(AfxIsValidAddress(pAssocRet, sizeof(CAssoc)));
//	CAssoc* pAssocNext;
//	if ((pAssocNext = pAssocRet->pNext) == NULL)
//	{
//		// go to next bucket
//		for (UINT nBucket = (pAssocRet->nHashValue % m_nHashTableSize) + 1;
//		  nBucket < m_nHashTableSize; nBucket++)
//			if ((pAssocNext = m_pHashTable[nBucket]) != NULL)
//				break;
//	}
//
//	rNextPosition = (POSITION) pAssocNext;
//
//	// fill in return data
//	rKey = pAssocRet->key;
//	rValue = pAssocRet->value;
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//const typename CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::CPair*
//CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::PGetNextAssoc(const typename CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::CPair* pPairRet) const
//{
//	//ASSERT_VALID(this);
//
//	CAssoc* pAssocRet = (CAssoc*)pPairRet;
//
//	SPN_ASSERT(m_pHashTable != NULL);  // never call on empty map
//	SPN_ASSERT(pAssocRet != NULL);
//	
//	if(m_pHashTable == NULL || pAssocRet == NULL)
//		return NULL;
//		
//	SPN_ASSERT(pAssocRet != (CAssoc*)BEFORE_START_POSITION);
//
//	// find next association
//	SPN_ASSERT(AfxIsValidAddress(pAssocRet, sizeof(CAssoc)));
//	CAssoc* pAssocNext;
//	if ((pAssocNext = pAssocRet->pNext) == NULL)
//	{
//		// go to next bucket
//		for (UINT nBucket = (pAssocRet->nHashValue % m_nHashTableSize) + 1;
//		  nBucket < m_nHashTableSize; nBucket++)
//			if ((pAssocNext = m_pHashTable[nBucket]) != NULL)
//				break;
//	}
//
//	return pAssocNext;
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//typename CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::CPair*
//CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::PGetNextAssoc(const typename CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::CPair* pPairRet)
//{
//	//ASSERT_VALID(this);
//
//	CAssoc* pAssocRet = (CAssoc*)pPairRet;
//
//	SPN_ASSERT(m_pHashTable != NULL);  // never call on empty map
//	SPN_ASSERT(pAssocRet != NULL);
//	
//	if(m_pHashTable == NULL || pAssocRet == NULL)
//		return NULL;
//		
//	SPN_ASSERT(pAssocRet != (CAssoc*)BEFORE_START_POSITION);
//
//	// find next association
//	SPN_ASSERT(AfxIsValidAddress(pAssocRet, sizeof(CAssoc)));
//	CAssoc* pAssocNext;
//	if ((pAssocNext = pAssocRet->pNext) == NULL)
//	{
//		// go to next bucket
//		for (UINT nBucket = (pAssocRet->nHashValue % m_nHashTableSize) + 1;
//		  nBucket < m_nHashTableSize; nBucket++)
//			if ((pAssocNext = m_pHashTable[nBucket]) != NULL)
//				break;
//	}
//
//	return pAssocNext;
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//void CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::Serialize(CArchive& ar)
//{
//	//ASSERT_VALID(this);
//
//	CObject::Serialize(ar);
//
//	if (ar.IsStoring())
//	{
//		ar.WriteCount(m_nCount);
//		if (m_nCount == 0)
//			return;  // nothing more to do
//
//		SPN_ASSERT(m_pHashTable != NULL);
//		if (m_pHashTable != NULL)
//		{
//			for (UINT nHash = 0; nHash < m_nHashTableSize; nHash++)
//			{
//				CAssoc* pAssoc;
//				for (pAssoc = m_pHashTable[nHash]; pAssoc != NULL; pAssoc = pAssoc->pNext)
//				{
//					KEY* pKey;
//					VALUE* pValue;
//					/* 
//					* in some cases the & operator might be overloaded, and we cannot use it to 
//					* obtain the address of a given object.  We then use the following trick to 
//					* get the address
//					*/
//					pKey = reinterpret_cast< KEY* >( &reinterpret_cast< int& >( const_cast< KEY& > ( static_cast< const KEY& >( pAssoc->key ) ) ) );
//					pValue = reinterpret_cast< VALUE* >( &reinterpret_cast< int& >( static_cast< VALUE& >( pAssoc->value ) ) );
//					SerializeElements<KEY>(ar, pKey, 1);
//					SerializeElements<VALUE>(ar, pValue, 1);
//				}
//			}
//		}
//	}
//	else
//	{
//		DWORD_PTR nNewCount = ar.ReadCount();
//		while (nNewCount--)
//		{
//			KEY newKey[1];
//			VALUE newValue[1];
//			SerializeElements<KEY>(ar, newKey, 1);
//			SerializeElements<VALUE>(ar, newValue, 1);
//			SetAt(newKey[0], newValue[0]);
//		}
//	}
//}
//
//#ifdef _DEBUG
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//void CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::Dump(CDumpContext& dc) const
//{
//	CObject::Dump(dc);
//
//	dc << "with " << m_nCount << " elements";
//	if (dc.GetDepth() > 0)
//	{
//		// Dump in format "[key] -> value"
//		KEY key[1];
//		VALUE val[1];
//
//		POSITION pos = GetStartPosition();
//		while (pos != NULL)
//		{
//			GetNextAssoc(pos, key[0], val[0]);
//			dc << "\n\t[";
//			DumpElements<KEY>(dc, key, 1);
//			dc << "] = ";
//			DumpElements<VALUE>(dc, val, 1);
//		}
//	}
//
//	dc << "\n";
//}
//
//template<class KEY, class ARG_KEY, class VALUE, class ARG_VALUE>
//void CMap<KEY, ARG_KEY, VALUE, ARG_VALUE>::AssertValid() const
//{
//	CObject::AssertValid();
//
//	SPN_ASSERT(m_nHashTableSize > 0);
//	SPN_ASSERT(m_nCount == 0 || m_pHashTable != NULL);
//		// non-empty map should have hash table
//}
//#endif //  //_DEBUG
//
///*============================================================================*/
//// CTypedPtrArray<BASE_CLASS, TYPE>
//
//template<class BASE_CLASS, class TYPE>
//class CTypedPtrArray : public BASE_CLASS
//{
//public:
//	// Accessing elements
//	TYPE GetAt(int/*INT_PTR*/ nIndex) const
//		{ return (TYPE)BASE_CLASS::GetAt(nIndex); }
//	TYPE& ElementAt(int/*INT_PTR*/ nIndex)
//		{ return (TYPE&)BASE_CLASS::ElementAt(nIndex); }
//	void SetAt(int/*INT_PTR*/ nIndex, TYPE ptr)
//		{ BASE_CLASS::SetAt(nIndex, ptr); }
//
//	// Potentially growing the array
//	void SetAtGrow(int/*INT_PTR*/ nIndex, TYPE newElement)
//		{ BASE_CLASS::SetAtGrow(nIndex, newElement); }
//	int/*INT_PTR*/ Add(TYPE newElement)
//		{ return BASE_CLASS::Add(newElement); }
//	int/*INT_PTR*/ Append(const CTypedPtrArray<BASE_CLASS, TYPE>& src)
//		{ return BASE_CLASS::Append(src); }
//	void Copy(const CTypedPtrArray<BASE_CLASS, TYPE>& src)
//		{ BASE_CLASS::Copy(src); }
//
//	// Operations that move elements around
//	void InsertAt(int/*INT_PTR*/ nIndex, TYPE newElement, int/*INT_PTR*/ nCount = 1)
//		{ BASE_CLASS::InsertAt(nIndex, newElement, nCount); }
//	void InsertAt(int/*INT_PTR*/ nStartIndex, CTypedPtrArray<BASE_CLASS, TYPE>* pNewArray)
//		{ BASE_CLASS::InsertAt(nStartIndex, pNewArray); }
//
//	// overloaded operator helpers
//	TYPE operator[](int/*INT_PTR*/ nIndex) const
//		{ return (TYPE)BASE_CLASS::operator[](nIndex); }
//	TYPE& operator[](int/*INT_PTR*/ nIndex)
//		{ return (TYPE&)BASE_CLASS::operator[](nIndex); }
//};
//
///*============================================================================*/
//// CTypedPtrList<BASE_CLASS, TYPE>
//
//template<class BASE_CLASS, class TYPE>
//class _CTypedPtrList : public BASE_CLASS
//{
//public:
//// Construction
//	_CTypedPtrList(int/*INT_PTR*/ nBlockSize = 10)
//		: BASE_CLASS(nBlockSize) { }
//
//	// peek at head or tail
//	TYPE& GetHead()
//		{ return (TYPE&)BASE_CLASS::GetHead(); }
//	TYPE GetHead() const
//		{ return (TYPE)BASE_CLASS::GetHead(); }
//	TYPE& GetTail()
//		{ return (TYPE&)BASE_CLASS::GetTail(); }
//	TYPE GetTail() const
//		{ return (TYPE)BASE_CLASS::GetTail(); }
//
//	// get head or tail (and remove it) - don't call on empty list!
//	TYPE RemoveHead()
//		{ return (TYPE)BASE_CLASS::RemoveHead(); }
//	TYPE RemoveTail()
//		{ return (TYPE)BASE_CLASS::RemoveTail(); }
//
//	// iteration
//	TYPE& GetNext(POSITION& rPosition)
//		{ return (TYPE&)BASE_CLASS::GetNext(rPosition); }
//	TYPE GetNext(POSITION& rPosition) const
//		{ return (TYPE)BASE_CLASS::GetNext(rPosition); }
//	TYPE& GetPrev(POSITION& rPosition)
//		{ return (TYPE&)BASE_CLASS::GetPrev(rPosition); }
//	TYPE GetPrev(POSITION& rPosition) const
//		{ return (TYPE)BASE_CLASS::GetPrev(rPosition); }
//
//	// getting/modifying an element at a given position
//	TYPE& GetAt(POSITION position)
//		{ return (TYPE&)BASE_CLASS::GetAt(position); }
//	TYPE GetAt(POSITION position) const
//		{ return (TYPE)BASE_CLASS::GetAt(position); }
//	void SetAt(POSITION pos, TYPE newElement)
//		{ BASE_CLASS::SetAt(pos, newElement); }
//
//	// inserting before or after a given position
//	POSITION InsertBefore(POSITION position, TYPE newElement)
//		{ return BASE_CLASS::InsertBefore(position, newElement); }
//	POSITION InsertAfter(POSITION position, TYPE newElement)
//		{ return BASE_CLASS::InsertAfter(position, newElement); }
//
//	// transfer before or after a given position
//	// Transfer semantics ensure no leakage by deleting the element in the case of an exception
//	POSITION TransferInsertBefore(POSITION position, TYPE newElement)
//	{
//		try
//		{
//			return BASE_CLASS::InsertBefore(position, newElement); 
//		}
//		catch(...)
//		{
//			delete newElement;
//			throw;
//		}
//	}
//
//	POSITION TransferInsertAfter(POSITION position, TYPE newElement)
//	{
//		try
//		{
//			return BASE_CLASS::InsertAfter(position, newElement); 
//		}
//		catch(...)
//		{
//			delete newElement;
//			throw;
//		}
//	}
//};
//
//template<class BASE_CLASS, class TYPE>
//class CTypedPtrList : public _CTypedPtrList<BASE_CLASS, TYPE>
//{
//public:
//// Construction
//	CTypedPtrList(int/*INT_PTR*/ nBlockSize = 10)
//		: _CTypedPtrList<BASE_CLASS, TYPE>(nBlockSize) { }
//
//	// add before head or after tail
//	POSITION AddHead(TYPE newElement)
//		{ return BASE_CLASS::AddHead(newElement); }
//	POSITION AddTail(TYPE newElement)
//		{ return BASE_CLASS::AddTail(newElement); }
//
//	// transfer add before head or tail
//	POSITION TransferAddHead(TYPE newElement)
//	{ 
//		try
//		{
//			return BASE_CLASS::AddHead(newElement); 
//		}
//		catch(...)
//		{
//			delete newElement;
//			throw;
//		}
//	}
//	POSITION TransferAddTail(TYPE newElement)
//	{ 
//		try
//		{
//			return BASE_CLASS::AddTail(newElement); 
//		}
//		catch(...)
//		{
//			delete newElement;
//			throw;
//		}
//	}
//
//	// add another list of elements before head or after tail
//	void AddHead(CTypedPtrList<BASE_CLASS, TYPE>* pNewList)
//		{ BASE_CLASS::AddHead(pNewList); }
//	void AddTail(CTypedPtrList<BASE_CLASS, TYPE>* pNewList)
//		{ BASE_CLASS::AddTail(pNewList); }
//};
//
//// need specialized version for CObList because of AddHead/Tail ambiguity
//template<> class CTypedPtrList<CObList, CObList*>
//	: public _CTypedPtrList<CObList, CObList*>
//{
//public:
//// Construction
//	CTypedPtrList(int/*INT_PTR*/ nBlockSize = 10)
//		: _CTypedPtrList<CObList, CObList*>(nBlockSize) { }
//
//	// add before head or after tail
//	POSITION AddHead(CObList* newElement)
//		{ return _CTypedPtrList<CObList, CObList*>::AddHead((CObject*)newElement); }
//	POSITION AddTail(CObList* newElement)
//		{ return _CTypedPtrList<CObList, CObList*>::AddTail((CObject*)newElement); }
//
//	// add another list of elements before head or after tail
//	void AddHead(CTypedPtrList<CObList, CObList*>* pNewList)
//		{ _CTypedPtrList<CObList, CObList*>::AddHead(pNewList); }
//	void AddTail(CTypedPtrList<CObList, CObList*>* pNewList)
//		{ _CTypedPtrList<CObList, CObList*>::AddTail(pNewList); }
//};
//
//// need specialized version for CPtrList because of AddHead/Tail ambiguity
//template<> class CTypedPtrList<CPtrList, CPtrList*>
//	: public _CTypedPtrList<CPtrList, CPtrList*>
//{
//public:
//// Construction
//	CTypedPtrList(int/*INT_PTR*/ nBlockSize = 10)
//		: _CTypedPtrList<CPtrList, CPtrList*>(nBlockSize) { }
//
//	// add before head or after tail
//	POSITION AddHead(CPtrList* newElement)
//		{ return _CTypedPtrList<CPtrList, CPtrList*>::AddHead((void*)newElement); }
//	POSITION AddTail(CPtrList* newElement)
//		{ return _CTypedPtrList<CPtrList, CPtrList*>::AddTail((void*)newElement); }
//
//	// add another list of elements before head or after tail
//	void AddHead(CTypedPtrList<CPtrList, CPtrList*>* pNewList)
//		{ _CTypedPtrList<CPtrList, CPtrList*>::AddHead(pNewList); }
//	void AddTail(CTypedPtrList<CPtrList, CPtrList*>* pNewList)
//		{ _CTypedPtrList<CPtrList, CPtrList*>::AddTail(pNewList); }
//};
//
///*============================================================================*/
//// CTypedPtrMap<BASE_CLASS, KEY, VALUE>
//
//template<class BASE_CLASS, class KEY, class VALUE>
//class CTypedPtrMap : public BASE_CLASS
//{
//public:
//
//// Construction
//	CTypedPtrMap(int/*INT_PTR*/ nBlockSize = 10)
//		: BASE_CLASS(nBlockSize) { }
//
//	// Lookup
//	BOOL Lookup(typename BASE_CLASS::BASE_ARG_KEY key, VALUE& rValue) const
//		{ return BASE_CLASS::Lookup(key, (BASE_CLASS::BASE_VALUE&)rValue); }
//
//	// Lookup and add if not there
//	VALUE& operator[](typename BASE_CLASS::BASE_ARG_KEY key)
//		{ return (VALUE&)BASE_CLASS::operator[](key); }
//
//	// add a new key (key, value) pair
//	void SetAt(KEY key, VALUE newValue)
//		{ BASE_CLASS::SetAt(key, newValue); }
//
//	// removing existing (key, ?) pair
//	BOOL RemoveKey(KEY key)
//		{ return BASE_CLASS::RemoveKey(key); }
//
//	// iteration
//	void GetNextAssoc(POSITION& rPosition, KEY& rKey, VALUE& rValue) const
//		{ BASE_CLASS::GetNextAssoc(rPosition, (BASE_CLASS::BASE_KEY&)rKey,
//			(BASE_CLASS::BASE_VALUE&)rValue); }
//};
//
///////////////////////////////////////////////////////////////////////////////
//
//#undef THIS_FILE
//#define THIS_FILE __FILE__
//
//#	pragma pop_macro("new")
//
//#ifdef _AFX_PACKING
//#	pragma pack(pop)
//#endif // 
//
//#ifdef _AFX_MINREBUILD
//#	pragma component(minrebuild, on)
//#endif // 
//
//#	pragma warning( pop )
//
#endif //  //__AFXTEMPL_H__

/////////////////////////////////////////////////////////////////////////////
