#ifndef _SPN_Cmn_Math__AllExport__INCLUDED_
#define	_SPN_Cmn_Math__AllExport__INCLUDED_

#pragma once

#define SPN_Cmn_Math_LIB

#include "_SPN_Cmn_Math__Include.h"

#endif //  // !defined(_SPN_Cmn_Math__AllExport__INCLUDED_
