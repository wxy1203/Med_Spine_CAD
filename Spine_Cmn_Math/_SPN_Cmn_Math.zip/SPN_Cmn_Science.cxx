
#include "pch.h"
#include "_SPN_Cmn_Math__inLib.h"

//
#ifdef _DEBUG
#	ifdef _USE_VC_DBG_NEW
#		define new DEBUG_NEW
#	else
#		ifdef _USE_SPN_DBG_NEW
#			define new _DEBUG_NEW
//#			define delete _DEBUG_DEL
#		endif
#	endif
#endif // 
//

//#ifdef _DEBUG
//void Assert_Valid_DBLFLT(const DBLFLT& v)
//{
//	std::string S;
//	S.Format("%f",v);
//	std::string SzErr("#IND");
//	if(S.FindOneOf(SzErr)>=)
//	{
//		::ShowMsg(S);
//		abort();
//	}
//}
//#endif // 

