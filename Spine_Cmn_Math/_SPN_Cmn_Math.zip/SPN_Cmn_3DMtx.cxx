#include "pch.h"
#include "_SPN_Cmn_Math__inLib.h"
#include "SPN_Cmn_3DMtx.h"

#include "SPN_Cmn_3DMtx.h"
#include "SPN_Cmn_3DPoint.h"

void Test_Compile_SPN_Cmn_3DMtx(CSPN_Cmn_3DMtx<int>& rMtx_iB)
{
	CSPN_Cmn_3DMtx<int> Mtx_iA;
	{
		Mtx_iA.Set_nXYZ(0, 0, 5);
		Mtx_iA.SetP3D_Bgn(0, 0, 0);
		Mtx_iA.SetP3D_Spc(.5f, .5f, 0.f);

		//D
		for (int iVox = 0; iVox < Mtx_iA.GetSize_Mtx(); iVox++)
		{
			Mtx_iA.SetVox(iVox, rand()%3);
		}

		//3D
		int iVox = 0;
		for (int k = 0; k<Mtx_iA.GetSize_Z(); k++)
		{
			for (int j = 0; j < Mtx_iA.GetSize_Y(); j++)
			{
				for (int i = 0; i < Mtx_iA.GetSize_X(); i++, iVox++)
				{
					Mtx_iA.SetVox(i, j, k, rand() % 3);
				}
			}
		}

		Mtx_iA.Set_nXYZ(0, 0, 5);
		Mtx_iA.Set_nXYZ(0, 0, 5);
	}

	rMtx_iB;
	{
		//rMtx_iB.CopyMtx(Mtx_iA);

		assert(Mtx_iA.GetSize_Mtx() > 0);
		assert(rMtx_iB.GetSize_Mtx() == 0);

		rMtx_iB.Swap(Mtx_iA);

		assert(rMtx_iB.GetSize_Mtx() > 0);
		assert(Mtx_iA.GetSize_Mtx() == 0);
	}
}
//
//CSPN_Cmn_3DMtx<int>&& Test_Swap_3DMtx()
//{
//	CSPN_Cmn_3DMtx<int> Mtx_iA;
//	{
//		Mtx_iA.Set_nXYZ(, , 5);
//		Mtx_iA.SetP3D_Bgn(, , );
//		Mtx_iA.SetP3D_Spc(.5f, .5f, .f);
//
//		//D
//		for (int iVox = ; iVox < Mtx_iA.GetSize_Mtx(); iVox++)
//		{
//			Mtx_iA.SetVox(iVox, rand()%);
//		}
//
//		//3D
//		int iVox = ;
//		for (int k = ; k<Mtx_iA.GetSize_Z(); k++)
//		{
//			for (int j = ; j < Mtx_iA.GetSize_Y(); j++)
//			{
//				for (int i = ; i < Mtx_iA.GetSize_X(); i++, iVox++)
//				{
//					/iVox = Mtx_iA.GetVoxID(CSPN_Cmn_3DPoint<int>(i,j,k));/
//
//					Mtx_iA.SetVox(i, j, k, rand() % );
//				}
//			}
//		}
//
//		Mtx_iA.Set_nXYZ(, , 5);
//		Mtx_iA.Set_nXYZ(, , 5);
//	}
//
//	return Mtx_iA;
//
//	///CSPN_Cmn_3DMtx<int> /rMtx_iB;
//	//{
//	//	//rMtx_iB.CopyMtx(Mtx_iA);
//
//	//	assert(Mtx_iA.GetSize_Mtx() > );
//	//	assert(rMtx_iB.GetSize_Mtx() == );
//
//	//	rMtx_iB.Swap(Mtx_iA);
//
//	//	assert(rMtx_iB.GetSize_Mtx() > );
//	//	assert(Mtx_iA.GetSize_Mtx() == );
//	//}
//}
//
//void FunMain()
//{
//	CSPN_Cmn_3DMtx<int> MtxR;
//	MtxR.Swap(Test_Swap_3DMtx());
//
//	//std::map<int, int>::swap()
//}