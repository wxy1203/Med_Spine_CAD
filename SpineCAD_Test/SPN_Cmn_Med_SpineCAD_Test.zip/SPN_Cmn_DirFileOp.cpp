
#include "SPN_Cmn_DirFileOp.h"

#include "QVariant"
#include <QFile>
#include <QFileInfo>
#include <QFileDialog>

//**************************************************************

void SPN_Cmn_DirFileOp::Ensure_HasFile(QString StrFilePath)
{
	if (QFile::exists(StrFilePath))
	{
		return;
	}
	else
	{
		assert(false);//Wait for coding
	}
}

void SPN_Cmn_DirFileOp::Ensure_DelFile(QString StrFilePath/*in*/)
{
	if (!QFile::exists(StrFilePath))
	{
		return;
	}
	else
	{
		QFile F(StrFilePath);
		F.remove();
	}
}

bool SPN_Cmn_DirFileOp::GetSel_PathFile_by_BrowseUI_forLoad(QString& StrFilePath/*out*/,
														   QString StrPrompt,
														   QString StrDirPath_Def)
{
	StrFilePath = QFileDialog::getOpenFileName(nullptr, StrPrompt, StrDirPath_Def);
	bool bOK = StrFilePath.size() > 0;
	return bOK;
}

bool SPN_Cmn_DirFileOp::GetSel_PathFile_by_BrowseUI_forSave(QString& StrFilePath/*out*/,
														   QString StrPrompt,
														   QString StrDirPath_Def)
{
	StrFilePath = QFileDialog::getSaveFileName(nullptr, StrPrompt, StrDirPath_Def);
	bool bOK = StrFilePath.size() > 0;
	return bOK;
}


bool SPN_Cmn_DirFileOp::GetSel_PathDir_by_BrowseUI(QString& StrDirPath/*out*/,
												  QString StrPrompt,
												  QString StrDirPath_Def)
{
	StrDirPath = QFileDialog::getExistingDirectory(nullptr, StrPrompt, StrDirPath_Def);
	bool bOK = StrDirPath.size() > 0;
	return bOK;
}


