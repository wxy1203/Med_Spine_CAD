#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_SPN_Cmn_Dlg_Main.h"

class SPN_Cmn_DlgPane_ShowPic;

class SPN_Cmn_Dlg_Main : public QDialog
{
	Q_OBJECT

public:
	SPN_Cmn_Dlg_Main(QWidget *parent = nullptr);
	~SPN_Cmn_Dlg_Main();

public slots:
	void resizeEvent(QResizeEvent *) override;

protected:
	void RePos_UI();

private:
	Ui::SPN_Cmn_Dlg_Main ui;

	SPN_Cmn_DlgPane_ShowPic* m_pPane_Ax		= nullptr; // Ax -- Axial	(����棬��״�棩
	SPN_Cmn_DlgPane_ShowPic* m_pPane_Co		= nullptr; // Co -- Coronal	(��״��)
	SPN_Cmn_DlgPane_ShowPic* m_pPane_Sa		= nullptr; // Sa -- Saggitl	(ʸ״��)

	SPN_Cmn_DlgPane_ShowPic* m_pPane_Slash	= nullptr; // б����

	SPN_Cmn_DlgPane_ShowPic*	m_pPane_3D		= nullptr; // 3D

	bool					m_bInitPns		= false;
};

