
#include "SPN_Cmn_Dlg_DbgImg.h"
#include "SPN_Cmn_DlgPane_ShowPic.h"

void SPN_Cmn_Dlg_DbgImg::StepNewCalc()
{
	m_nStepClc++;
	m_fAPhase = -float(m_nStepClc) / 12.f;

	Test_ShowImg2D();
}
//void SPN_Cmn_Dlg_DbgImg::OnListenTm()
//{
//	m_nStepClc++;
//	m_fAPhase = -float(m_nStepClc) / 12.f;
//
//	Test_ShowImg2D();
//}

SPN_Cmn_Dlg_DbgImg::SPN_Cmn_Dlg_DbgImg(QWidget *parent/* = nullptr*/)
	: QDialog(parent)
{
	//1
	ui.setupUi(this);

	//2
	m_pPanePic = new SPN_Cmn_DlgPane_ShowPic(this);
	//m_pPanePic->setVisible(true);
	m_pPanePic->show();

	//m_pPanePic->m_Timer.AddListener(this);
	//connect(&(m_pPanePic->m_Timer), SIGNAL(timeout), this, SLOT(StepNewCalc));
	//connect(&(m_pPanePic->m_Timer), SIGNAL(myTimeOut), this, SLOT(StepNewCalc));
	connect(&(m_pPanePic->m_Timer), &MyTimer::myTimeOut, this, &SPN_Cmn_Dlg_DbgImg::StepNewCalc);

	////3
	//Test_ShowImg2D();

	const int C_nSpring = 3;
	m_Arr_pSping.resize(C_nSpring);
	{
		for (int i = 0; i < m_Arr_pSping.size(); i++)
		{
			m_Arr_pSping[i] = new Spring;
		}
	}

}

SPN_Cmn_Dlg_DbgImg::~SPN_Cmn_Dlg_DbgImg()
{
	m_Arr_pSping;
	{
		for (int i = 0; i < m_Arr_pSping.size(); i++)
		{
			if (m_Arr_pSping[i])
			{
				delete m_Arr_pSping[i];
				m_Arr_pSping[i] = nullptr;
			}
		}
	}
}

void SPN_Cmn_Dlg_DbgImg::Test_ShowImg2D()
{
	//1
	S_Img2D* pImgSum = new S_Img2D;
	{
		pImgSum->Construct(Spring::E_C_nW_Img, Spring::E_C_nH_Img);
		::memset(pImgSum->m_pfImgBuf, 0, sizeof(float)*(pImgSum->Get_nXY()));
	}

	//2
	Spring::CalcSumImg(*pImgSum, m_Arr_pSping, m_fAPhase);

	//3
	m_pPanePic->ShowImg2D(*pImgSum);
}

void SPN_Cmn_Dlg_DbgImg::resizeEvent(QResizeEvent* pReszEv)
{
	const int C_nWEdge = 2;
	const int C_nHEdge = 2;
	m_pPanePic->move(C_nWEdge, C_nHEdge);

	QSize SzWnd = this->size();
	SzWnd.setWidth (SzWnd.width ()-2*C_nWEdge);
	SzWnd.setHeight(SzWnd.height()-2*C_nHEdge);
	m_pPanePic->resize(SzWnd);
}



