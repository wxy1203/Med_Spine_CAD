#include "SPN_Cmn_Med_SpineCAD.h"
#include "SPN_Cmn_Dlg_DbgImg.h"
#include "SPN_Cmn_Dlg_Main.h"

SPN_Cmn_Med_SpineCAD::SPN_Cmn_Med_SpineCAD(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

SPN_Cmn_Med_SpineCAD::~SPN_Cmn_Med_SpineCAD()
{
}

void SPN_Cmn_Med_SpineCAD::on_Btn_ShowDlg_DbgImg_clicked()
{
	SPN_Cmn_Dlg_DbgImg Dlg_DbgImg;

	Dlg_DbgImg.setVisible(true);
	Dlg_DbgImg.exec();
}

void SPN_Cmn_Med_SpineCAD::on_Btn_ShowDlg_Main_clicked()
{
	SPN_Cmn_Dlg_Main Dlg_Main;

	Dlg_Main.setVisible(true);
	Dlg_Main.exec();
}


