#pragma once

#include <QString>

class SPN_Cmn_DirFileOp
{
public:
	static void Ensure_HasFile(QString StrFilePath/*in*/);
	static void Ensure_DelFile(QString StrFilePath/*in*/);
	static bool GetSel_PathFile_by_BrowseUI_forLoad(QString& StrFilePath/*out*/,
													QString StrPrompt,
													QString StrDirPath_Def);
	static bool GetSel_PathFile_by_BrowseUI_forSave(QString& StrFilePath/*out*/,
													QString StrPrompt,
													QString StrDirPath_Def);

	static bool GetSel_PathDir_by_BrowseUI(QString& StrDirPath/*out*/,
										   QString StrPrompt,
										   QString StrDirPath_Def);
protected:
	SPN_Cmn_DirFileOp() {};
	~SPN_Cmn_DirFileOp() {};
};

