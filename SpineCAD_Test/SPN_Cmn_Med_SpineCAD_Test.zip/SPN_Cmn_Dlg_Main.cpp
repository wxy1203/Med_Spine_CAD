
#include "SPN_Cmn_Dlg_Main.h"
#include "SPN_Cmn_DlgPane_ShowPic.h"

SPN_Cmn_Dlg_Main::SPN_Cmn_Dlg_Main(QWidget *parent/* = nullptr*/)
	: QDialog(parent)
	, m_bInitPns(false)
{
	ui.setupUi(this);

	m_pPane_Ax = new SPN_Cmn_DlgPane_ShowPic(this);
	m_pPane_Ax->show();

	m_pPane_Co = new SPN_Cmn_DlgPane_ShowPic(this);
	m_pPane_Co->show();

	m_pPane_Sa = new SPN_Cmn_DlgPane_ShowPic(this);
	m_pPane_Sa->show();

	m_pPane_Slash = new SPN_Cmn_DlgPane_ShowPic(this);
	m_pPane_Slash->show();

	m_pPane_3D = new SPN_Cmn_DlgPane_ShowPic(this);
	m_pPane_3D->show();

	this->m_bInitPns = true;
}

SPN_Cmn_Dlg_Main::~SPN_Cmn_Dlg_Main()
{
}

void SPN_Cmn_Dlg_Main::RePos_UI()
{
	if(!m_bInitPns)
	{
		return;
	}
	//Ax(L-LT_Pane)-------------------------------------------------------
	//Co(L-LB_Pane)-------------------------------------------------------
	QSize SzDlg = this->size();
	
	const int C_nW_Edge = 5;
	const int C_nH_Edge = 5;

	const int C_nW_Spc = 2;
	const int C_nH_Spc = 2;

	int nH_RgnPn4 = SzDlg.height() - 2 * C_nH_Edge;
	int nW_RgnPn4 = nH_RgnPn4;

	QSize SzRgnPn4(nW_RgnPn4, nH_RgnPn4);
	QPoint PsRgnPn4(C_nW_Edge, C_nH_Edge);

	int nH_Pn_LLT = (SzRgnPn4.height() - C_nH_Spc) / 2;
	int nH_Pn_LLB = (SzRgnPn4.height() - C_nH_Spc - nH_Pn_LLT);

	int nW_Pn_LLT = nH_Pn_LLT;
	int nW_Pn_LLB = nW_Pn_LLT;

	//L-LT
	m_pPane_Ax->move(PsRgnPn4);
	m_pPane_Ax->resize(nW_Pn_LLT, nH_Pn_LLT);

	//L-LB
	m_pPane_Co->move(PsRgnPn4.x(), C_nH_Edge + nH_Pn_LLT + C_nH_Spc);
	m_pPane_Co->resize(nW_Pn_LLB, nH_Pn_LLB);

	//Slash(LRT_Pane)----------------------------------------------------
	//Sa(L-RB_Pane)-------------------------------------------------------
	QPoint PsLRT(C_nW_Edge + nW_Pn_LLT + C_nW_Spc, C_nH_Edge);
	QSize  SzLRT = m_pPane_Ax->size();
	m_pPane_Slash->move(PsLRT);
	m_pPane_Slash->resize(SzLRT);

	QPoint PsLRB(PsLRT.x(), m_pPane_Co->pos().y());
	QSize  SzLRB = m_pPane_Co->size();
	m_pPane_Sa->move  (PsLRB);
	m_pPane_Sa->resize(SzLRB);

	//3D(Mid_Pane)-------------------------------------------------------
	QRect RctLRT = m_pPane_Slash->rect();
	QPoint PsTR_LRT_inPa = m_pPane_Slash->mapToParent(RctLRT.topRight());

	QPoint PsM3D(PsTR_LRT_inPa.x() + C_nW_Spc,
				 m_pPane_Slash->pos().y());

	int nW_netW_MnR = SzDlg.width()- SzRgnPn4.width() - C_nW_Edge*2 - C_nW_Spc*2;
	int nW_M3D = nW_netW_MnR * 2 / 3;
	QSize  SzM3D(nW_M3D, SzRgnPn4.height());
	m_pPane_3D->move(PsM3D);
	m_pPane_3D->resize(SzM3D);
}

void SPN_Cmn_Dlg_Main::resizeEvent(QResizeEvent *pReszEvnt)
{
	this->RePos_UI();
}
