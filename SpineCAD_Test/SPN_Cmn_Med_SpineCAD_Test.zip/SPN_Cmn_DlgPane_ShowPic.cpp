
#include "SPN_Cmn_DlgPane_ShowPic.h"
#include "SPN_Cmn_DirFileOp.h"

#include <QPainter>
#include <QRectF>
#include <QVector>
#include <QResizeEvent>
#include <QColor>
#include <QWidget>
#include "windows.h"

//----------------------------------------------------------------------------------------------

bool SPN_Cmn_DlgPane_ShowPic::ReadImg()
{
	QString StrFPth_Img;
	{
		QString StrTitle("Sel image file for read and show: ");
		QString StrDirDef("D:/Img");
		bool bOkImgF = SPN_Cmn_DirFileOp::GetSel_PathFile_by_BrowseUI_forLoad(StrFPth_Img, StrTitle, StrDirDef);
		if (!bOkImgF)
		{
			return false;
		}
	}

	bool bOK_Load = m_QMemImg_VM.load(StrFPth_Img);

	return bOK_Load;
}

bool SPN_Cmn_DlgPane_ShowPic::CalcMemImg()
{
	//1.------------------------------------------------------
	if (nullptr == m_psImgData_MV)
	{
		return false;
	}

	int nXY = m_psImgData_MV->Get_nXY();
	if (0 == nXY)
	{
		return false;
	}

	//2.------------------------------------------------------
	float fMin = FLT_MAX;
	float fMax = FLT_MAX;
	m_psImgData_MV->FindMinMax(fMin, fMax);

	//3.------------------------------------------------------
	m_psImgData_MV->MapTo_GreyImg_LoUp(m_QMemImg_VM, fMin, fMax);

	return true;
}
//----------------------------------------------------------------------------------------------


//----------------------------------------------------------------------------------------------
SPN_Cmn_DlgPane_ShowPic::SPN_Cmn_DlgPane_ShowPic(QWidget *parent)
    : QWidget(parent)
	, m_nStep(0)
	//,m_RctDst
	//,m_RctImg
{
    m_uiPnPic.setupUi(this);/*
	m_psImgData_MV->Init();*/

	const int C_nFrmPerScd = 33;
	
//Q_SIGNALS:
//	void timeout(QPrivateSignal);

	m_Timer.start(C_nFrmPerScd);

	//connect(&m_Timer, SIGNAL(timeout), this, SLOT(StepNewDraw));
	//connect(&m_Timer, SIGNAL(myTimeOut), this, SLOT(StepNewDraw));
	connect(&m_Timer, &MyTimer::myTimeOut, this, &SPN_Cmn_DlgPane_ShowPic::StepNewDraw);

	//m_Timer.AddListener(this);//Im
}
//----------------------------------------------------------------------------------------------

SPN_Cmn_DlgPane_ShowPic::~SPN_Cmn_DlgPane_ShowPic()
{
	if (m_psImgData_MV)
	{
		delete m_psImgData_MV;
		m_psImgData_MV = nullptr;
	}
}

void SPN_Cmn_DlgPane_ShowPic::ShowImg2D(const S_Img2D& sImgMV)
{
	if (m_psImgData_MV)
	{
		delete m_psImgData_MV;
		m_psImgData_MV = nullptr;
	}
	m_psImgData_MV = &(const_cast<S_Img2D&>(sImgMV));

	QWidget::repaint();
}

void SPN_Cmn_DlgPane_ShowPic::StepNewDraw()
{
	int iBrk = 0;

	if (0 == m_nStep)
	{
		/*QRect*/ m_RctDst = this->rect();
		/*QRect*/ m_RctImg = m_QMemImg_VM.rect();
		m_nDx = 2;
		m_nDy = 2;
	}
	else
	{
		static bool bMv = 0;
		if (bMv)
		{
			if (m_RctDst.left() > this->rect().right() ||
				m_RctDst.right() < 0)
			{
				m_nDx *= -1;
			}

			if (m_RctDst.top() > this->rect().bottom() ||
				m_RctDst.bottom() < 0)
			{
				m_nDy *= -1;
			}

			m_RctDst.adjust(m_nDx, m_nDy,
							m_nDx, m_nDy);
			//m_RctImg;
		}
		else
		{
			/*QRect*/ m_RctDst = this->rect();
			/*QRect*/ m_RctImg = m_QMemImg_VM.rect();
		}
	}

	m_nStep++;

	this->repaint();
}

void SPN_Cmn_DlgPane_ShowPic::paintEvent(QPaintEvent* pEvntPaint)
{
	//int iBrk = 1;

	if (1)
	{
		DoDraw(pEvntPaint);
	}
	else
	{
		//DoDraw1(pEvntPaint);
	}
};

void SPN_Cmn_DlgPane_ShowPic::DoDraw(QPaintEvent *pEvntPaint)
{
	//0.Prepair: ------------------------------------------------------------------------------
	QPainter Painter(this);	
	Painter.save();

	//1.//Draw FrameLn-------------------------------------------------------------------------
	assert(true);
	{
		QSize SzPn = this->size();
		SzPn.setWidth(SzPn.width() - 2);
		SzPn.setHeight(SzPn.height() - 2);
		QPen PenFrm;
		{
			PenFrm.setWidth(1);
			PenFrm.setColor(QColor(100, 100, 100));
		}
		Painter.setPen(PenFrm);

		Painter.drawRect(QRect(1, 1, SzPn.width(), SzPn.height()));
	}

	//2.PaintImg: -----------------------------------------------------------------------------
	bool bChg = UpdateMemImg();
	if (!m_QMemImg_VM.isNull())
	{
		//*********************************************************
		Painter.drawImage(m_RctDst, m_QMemImg_VM, m_RctImg);
	}

	//3.DrawGraph------------------------------------------------------------------------------

	assert(true);
	static bool bTestDrawGraph = 0;
	if (bTestDrawGraph)
	{
		srand(GetTickCount());

		QPen Pen;
		{
			Pen.setWidth(2);
			Pen.setColor(/*QColor(*/Qt::red/*)*/);
			//Pen.setColor(QColor(Qt::red));
			//QColor Clr(Qt::green);
			//Pen.setColor(Clr);
			//Pen.setColor(QColor(Qt::green));
			//Pen.setColor(Qt::green);
		}
		Painter.setPen(Pen);
		{
			int iX = 10;
			int iY = 15;
			for (int i = 0; i < 10/*000*/; i++)
			{
				QRectF RctF((iX + i * 2 + rand()) % 1500, (15 + i * 2 + rand()) % 1000, 100, 80);
				Painter.drawEllipse(RctF);
			}
		}

		//--------------------------------------------------------
		QPen PenL;
		{
			PenL.setWidth(1);
			PenL.setColor(/*QColor(*/Qt::green/*)*/);
			//Pen.setColor(QColor(Qt::red));
			//QColor Clr(Qt::green);
			//Pen.setColor(Clr);
			//Pen.setColor(QColor(Qt::green));
			//Pen.setColor(Qt::green);
		}
		Painter.setPen(PenL);
		{
			QLine Ln(100, 100, 500, 300);
			Painter.drawLine(Ln);
		}
		//-------------------------------------------------------
		PenL.setColor(QColor(50, 80, 200));
		PenL.setWidth(5);
		Painter.setPen(PenL);
		{
			QVector<QPoint> ArrP2;
			{
				//ArrP2.resize(5);
				for (int j = 0; j < 6; j++)
				{
					if (j > 1 && 0 == j % 2)
					{
						ArrP2.push_back(ArrP2[j - 1]);
					}
					else
					{
						ArrP2.push_back(QPoint(rand() % 1000, rand() % 800));
					}
				}

				ArrP2.push_back(ArrP2[ArrP2.size() - 1]);
				ArrP2.push_back(ArrP2[0]);
			}
			Painter.drawLines(ArrP2);
		}
		//-------------------------------------------------------
		QPen PenR;
		{
			PenR.setWidth(9);
			PenR.setColor(QColor(200, 50, 255));
			//Pen.setColor(QColor(Qt::red));
			//QColor Clr(Qt::green);
			//Pen.setColor(Clr);
			//Pen.setColor(QColor(Qt::green));
			//Pen.setColor(Qt::green);
		}
		Painter.setPen(PenR);
		Painter.drawRect(QRect(40, 40, 150, 160));
	}

	//4.EndPaint------------------------------------------------------------------------------
	Painter.restore();
	Painter.end();
}

void SPN_Cmn_DlgPane_ShowPic::resizeEvent(QResizeEvent* /*pEvntSz*/)
{
	//pEvntSz->
	this->repaint();//>invalidate();
}

void SPN_Cmn_DlgPane_ShowPic::moveEvent(QMoveEvent*)
{
	this->repaint();//>invalidate();
}

bool SPN_Cmn_DlgPane_ShowPic::UpdateMemImg()
{

	CalcMemImg();

	return false;
}
