/********************************************************************************
** Form generated from reading UI file 'SPN_Cmn_Dlg_DbgImg.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SPN_CMN_DLG_DBGIMG_H
#define UI_SPN_CMN_DLG_DBGIMG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>

QT_BEGIN_NAMESPACE

class Ui_SPN_Cmn_Dlg_DbgImg
{
public:

    void setupUi(QDialog *SPN_Cmn_Dlg_DbgImg)
    {
        if (SPN_Cmn_Dlg_DbgImg->objectName().isEmpty())
            SPN_Cmn_Dlg_DbgImg->setObjectName(QString::fromUtf8("SPN_Cmn_Dlg_DbgImg"));
        SPN_Cmn_Dlg_DbgImg->resize(521, 304);

        retranslateUi(SPN_Cmn_Dlg_DbgImg);

        QMetaObject::connectSlotsByName(SPN_Cmn_Dlg_DbgImg);
    } // setupUi

    void retranslateUi(QDialog *SPN_Cmn_Dlg_DbgImg)
    {
        SPN_Cmn_Dlg_DbgImg->setWindowTitle(QApplication::translate("SPN_Cmn_Dlg_DbgImg", "Dlg_DbgImg", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SPN_Cmn_Dlg_DbgImg: public Ui_SPN_Cmn_Dlg_DbgImg {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SPN_CMN_DLG_DBGIMG_H
