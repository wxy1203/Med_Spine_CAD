/********************************************************************************
** Form generated from reading UI file 'SPN_Cmn_Wnd_Vtk3D.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SPN_CMN_WND_VTK3D_H
#define UI_SPN_CMN_WND_VTK3D_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SPN_Cmn_Wnd_Vtk3D
{
public:

    void setupUi(QWidget *SPN_Cmn_Wnd_Vtk3D)
    {
        if (SPN_Cmn_Wnd_Vtk3D->objectName().isEmpty())
            SPN_Cmn_Wnd_Vtk3D->setObjectName(QString::fromUtf8("SPN_Cmn_Wnd_Vtk3D"));
        SPN_Cmn_Wnd_Vtk3D->resize(400, 300);

        retranslateUi(SPN_Cmn_Wnd_Vtk3D);

        QMetaObject::connectSlotsByName(SPN_Cmn_Wnd_Vtk3D);
    } // setupUi

    void retranslateUi(QWidget *SPN_Cmn_Wnd_Vtk3D)
    {
        SPN_Cmn_Wnd_Vtk3D->setWindowTitle(QApplication::translate("SPN_Cmn_Wnd_Vtk3D", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SPN_Cmn_Wnd_Vtk3D: public Ui_SPN_Cmn_Wnd_Vtk3D {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SPN_CMN_WND_VTK3D_H
