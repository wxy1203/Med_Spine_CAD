/********************************************************************************
** Form generated from reading UI file 'SPN_Cmn_DlgPane_ShowPic.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SPN_CMN_DLGPANE_SHOWPIC_H
#define UI_SPN_CMN_DLGPANE_SHOWPIC_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SPN_Cmn_DlgPane_ShowPic
{
public:

    void setupUi(QWidget *SPN_Cmn_DlgPane_ShowPic)
    {
        if (SPN_Cmn_DlgPane_ShowPic->objectName().isEmpty())
            SPN_Cmn_DlgPane_ShowPic->setObjectName(QString::fromUtf8("SPN_Cmn_DlgPane_ShowPic"));
        SPN_Cmn_DlgPane_ShowPic->resize(400, 300);

        retranslateUi(SPN_Cmn_DlgPane_ShowPic);

        QMetaObject::connectSlotsByName(SPN_Cmn_DlgPane_ShowPic);
    } // setupUi

    void retranslateUi(QWidget *SPN_Cmn_DlgPane_ShowPic)
    {
        SPN_Cmn_DlgPane_ShowPic->setWindowTitle(QApplication::translate("SPN_Cmn_DlgPane_ShowPic", "PanePic", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SPN_Cmn_DlgPane_ShowPic: public Ui_SPN_Cmn_DlgPane_ShowPic {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SPN_CMN_DLGPANE_SHOWPIC_H
