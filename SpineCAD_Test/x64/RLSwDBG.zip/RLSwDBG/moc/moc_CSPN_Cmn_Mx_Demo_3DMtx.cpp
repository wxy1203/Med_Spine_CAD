/****************************************************************************
** Meta object code from reading C++ file 'CSPN_Cmn_Mx_Demo_3DMtx.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../CSPN_Cmn_Mx_Demo_3DMtx.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'CSPN_Cmn_Mx_Demo_3DMtx.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_CSPN_Cmn_Mx_Demo_3DMtx_t {
    QByteArrayData data[27];
    char stringdata0[335];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CSPN_Cmn_Mx_Demo_3DMtx_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CSPN_Cmn_Mx_Demo_3DMtx_t qt_meta_stringdata_CSPN_Cmn_Mx_Demo_3DMtx = {
    {
QT_MOC_LITERAL(0, 0, 22), // "CSPN_Cmn_Mx_Demo_3DMtx"
QT_MOC_LITERAL(1, 23, 16), // "Sn_ShowImgSlc_Ax"
QT_MOC_LITERAL(2, 40, 0), // ""
QT_MOC_LITERAL(3, 41, 8), // "S_Img2D*"
QT_MOC_LITERAL(4, 50, 7), // "pImgSum"
QT_MOC_LITERAL(5, 58, 7), // "kSlcImg"
QT_MOC_LITERAL(6, 66, 16), // "Sn_ShowImgSlc_Co"
QT_MOC_LITERAL(7, 83, 7), // "jSlcImg"
QT_MOC_LITERAL(8, 91, 16), // "Sn_ShowImgSlc_Sa"
QT_MOC_LITERAL(9, 108, 7), // "iSlcImg"
QT_MOC_LITERAL(10, 116, 19), // "Sn_ShowImgSlc_Slash"
QT_MOC_LITERAL(11, 136, 9), // "Sn_FocChg"
QT_MOC_LITERAL(12, 146, 24), // "SSPN_Cmn_3DPoint<float>&"
QT_MOC_LITERAL(13, 171, 9), // "sP3FocImg"
QT_MOC_LITERAL(14, 181, 10), // "iPn_ChgSrc"
QT_MOC_LITERAL(15, 192, 12), // "OnFocChg_MPR"
QT_MOC_LITERAL(16, 205, 9), // "iS_0X1Y2Z"
QT_MOC_LITERAL(17, 215, 6), // "P2FocL"
QT_MOC_LITERAL(18, 222, 5), // "sP3_G"
QT_MOC_LITERAL(19, 228, 26), // "iSelImgTp_0MPR_1DRR_2MaxIP"
QT_MOC_LITERAL(20, 255, 10), // "onSlashChg"
QT_MOC_LITERAL(21, 266, 11), // "iPnSlashing"
QT_MOC_LITERAL(22, 278, 23), // "SSPN_Cmn_3DPoint<float>"
QT_MOC_LITERAL(23, 302, 4), // "P3G1"
QT_MOC_LITERAL(24, 307, 4), // "P3G2"
QT_MOC_LITERAL(25, 312, 14), // "onImgTp_SelChg"
QT_MOC_LITERAL(26, 327, 7) // "iSel_Tp"

    },
    "CSPN_Cmn_Mx_Demo_3DMtx\0Sn_ShowImgSlc_Ax\0"
    "\0S_Img2D*\0pImgSum\0kSlcImg\0Sn_ShowImgSlc_Co\0"
    "jSlcImg\0Sn_ShowImgSlc_Sa\0iSlcImg\0"
    "Sn_ShowImgSlc_Slash\0Sn_FocChg\0"
    "SSPN_Cmn_3DPoint<float>&\0sP3FocImg\0"
    "iPn_ChgSrc\0OnFocChg_MPR\0iS_0X1Y2Z\0"
    "P2FocL\0sP3_G\0iSelImgTp_0MPR_1DRR_2MaxIP\0"
    "onSlashChg\0iPnSlashing\0SSPN_Cmn_3DPoint<float>\0"
    "P3G1\0P3G2\0onImgTp_SelChg\0iSel_Tp"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CSPN_Cmn_Mx_Demo_3DMtx[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,   54,    2, 0x06 /* Public */,
       6,    2,   59,    2, 0x06 /* Public */,
       8,    2,   64,    2, 0x06 /* Public */,
      10,    2,   69,    2, 0x06 /* Public */,
      11,    2,   74,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      15,    4,   79,    2, 0x0a /* Public */,
      20,    3,   88,    2, 0x0a /* Public */,
      25,    1,   95,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, QMetaType::Int,    4,    5,
    QMetaType::Void, 0x80000000 | 3, QMetaType::Int,    4,    7,
    QMetaType::Void, 0x80000000 | 3, QMetaType::Int,    4,    9,
    QMetaType::Void, 0x80000000 | 3, QMetaType::Int,    4,    5,
    QMetaType::Void, 0x80000000 | 12, QMetaType::Int,   13,   14,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::QPointF, 0x80000000 | 12, QMetaType::Int,   16,   17,   18,   19,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 22, 0x80000000 | 22,   21,   23,   24,
    QMetaType::Void, QMetaType::Int,   26,

       0        // eod
};

void CSPN_Cmn_Mx_Demo_3DMtx::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<CSPN_Cmn_Mx_Demo_3DMtx *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->Sn_ShowImgSlc_Ax((*reinterpret_cast< S_Img2D*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 1: _t->Sn_ShowImgSlc_Co((*reinterpret_cast< S_Img2D*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 2: _t->Sn_ShowImgSlc_Sa((*reinterpret_cast< S_Img2D*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 3: _t->Sn_ShowImgSlc_Slash((*reinterpret_cast< S_Img2D*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 4: _t->Sn_FocChg((*reinterpret_cast< SSPN_Cmn_3DPoint<float>(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 5: _t->OnFocChg_MPR((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QPointF(*)>(_a[2])),(*reinterpret_cast< SSPN_Cmn_3DPoint<float>(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 6: _t->onSlashChg((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const SSPN_Cmn_3DPoint<float>(*)>(_a[2])),(*reinterpret_cast< const SSPN_Cmn_3DPoint<float>(*)>(_a[3]))); break;
        case 7: _t->onImgTp_SelChg((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (CSPN_Cmn_Mx_Demo_3DMtx::*)(S_Img2D * , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CSPN_Cmn_Mx_Demo_3DMtx::Sn_ShowImgSlc_Ax)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (CSPN_Cmn_Mx_Demo_3DMtx::*)(S_Img2D * , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CSPN_Cmn_Mx_Demo_3DMtx::Sn_ShowImgSlc_Co)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (CSPN_Cmn_Mx_Demo_3DMtx::*)(S_Img2D * , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CSPN_Cmn_Mx_Demo_3DMtx::Sn_ShowImgSlc_Sa)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (CSPN_Cmn_Mx_Demo_3DMtx::*)(S_Img2D * , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CSPN_Cmn_Mx_Demo_3DMtx::Sn_ShowImgSlc_Slash)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (CSPN_Cmn_Mx_Demo_3DMtx::*)(SSPN_Cmn_3DPoint<float> & , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CSPN_Cmn_Mx_Demo_3DMtx::Sn_FocChg)) {
                *result = 4;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject CSPN_Cmn_Mx_Demo_3DMtx::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_CSPN_Cmn_Mx_Demo_3DMtx.data,
    qt_meta_data_CSPN_Cmn_Mx_Demo_3DMtx,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *CSPN_Cmn_Mx_Demo_3DMtx::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CSPN_Cmn_Mx_Demo_3DMtx::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CSPN_Cmn_Mx_Demo_3DMtx.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int CSPN_Cmn_Mx_Demo_3DMtx::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void CSPN_Cmn_Mx_Demo_3DMtx::Sn_ShowImgSlc_Ax(S_Img2D * _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void CSPN_Cmn_Mx_Demo_3DMtx::Sn_ShowImgSlc_Co(S_Img2D * _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void CSPN_Cmn_Mx_Demo_3DMtx::Sn_ShowImgSlc_Sa(S_Img2D * _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void CSPN_Cmn_Mx_Demo_3DMtx::Sn_ShowImgSlc_Slash(S_Img2D * _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void CSPN_Cmn_Mx_Demo_3DMtx::Sn_FocChg(SSPN_Cmn_3DPoint<float> & _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
